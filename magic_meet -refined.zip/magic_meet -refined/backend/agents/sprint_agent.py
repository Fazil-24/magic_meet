"""
Sprint Planner Agent — converts selected architecture into epics, stories, and a phased sprint plan.
"""
import json
from utils.llm_client import chat
from services.session_state import SessionState

SYSTEM_PROMPT = """You are a sprint planning expert. Given a selected architecture and team capacity,
create a detailed sprint plan with epics, user stories, and estimates.

Return ONLY valid JSON:
{
  "epics": [
    {
      "id": "E1",
      "title": "Epic title",
      "description": "one sentence",
      "sprint": 1,
      "stories": [
        {
          "id": "S1.1",
          "title": "As a [role], I want [feature] so that [benefit]",
          "size": "S|M|L",
          "days": 2,
          "acceptance_criteria": ["criterion 1", "criterion 2"],
          "dependencies": []
        }
      ]
    }
  ],
  "sprint_summary": [
    {"sprint": 1, "goal": "sprint goal", "stories": ["S1.1"], "total_days": 0, "focus": "description"}
  ],
  "risks": ["risk 1", "risk 2"],
  "open_items": ["item 1"],
  "total_sprints": 0,
  "confidence": "high|medium|low"
}"""


def run(session: SessionState) -> dict:
    session.update_agent(
        "sprint",
        status="running",
        task="Building sprint plan from selected architecture",
        confidence="",
    )

    summary = session.meeting_summary
    selected_arch = session.artifacts.get("selected_arch") or {}
    roi = session.artifacts.get("roi_scorecard", {})
    cp3_input = {}
    for cp in session.checkpoints:
        if cp.id == "cp3":
            cp3_input = cp.user_input

    context = {
        "project_objective": summary.get("summary", ""),
        "selected_architecture": selected_arch,
        "team": {
            "engineers": cp3_input.get("engineers", 2),
            "data_engineers": cp3_input.get("data_engineers", 1),
            "pm": cp3_input.get("pm", 1),
            "sprint_length_weeks": cp3_input.get("sprint_length_weeks", 2),
            "effective_days_per_sprint_per_engineer": 8,
        },
        "total_capacity_days_per_sprint": cp3_input.get("engineers", 2) * 8 + cp3_input.get("data_engineers", 1) * 8,
        "timeline_weeks": cp3_input.get("timeline_weeks", 10),
        "risks": summary.get("risks", []),
        "open_questions": summary.get("open_questions", []),
        "deferred_items": ["Invoice exception handling", "Analytics dashboards", "Advanced automation"],
    }

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Project context:\n{json.dumps(context, indent=2)}"},
    ]

    try:
        raw = chat(messages, temperature=0.3, max_tokens=3000)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception:
        result = _fallback_sprint()

    session.artifacts["sprint_backlog"] = result
    session.push_event("artifact_update", {"type": "sprint_backlog", "data": result})

    total = result.get("total_sprints", len(result.get("sprint_summary", [])))
    session.update_agent(
        "sprint",
        status="done",
        task="Sprint plan complete",
        output=f"{total} sprints planned. {len(result.get('epics', []))} epics, "
               f"{sum(len(e.get('stories', [])) for e in result.get('epics', []))} stories. "
               f"{len(result.get('risks', []))} risks identified.",
        confidence=result.get("confidence", "high"),
        artifacts=result.get("epics", []),
    )
    return result


def _fallback_sprint() -> dict:
    return {
        "epics": [
            {
                "id": "E1",
                "title": "Document Ingestion & OCR",
                "description": "Ingest expense receipts and extract structured data via Azure Document Intelligence.",
                "sprint": 1,
                "stories": [
                    {"id": "S1.1", "title": "As a developer, I want to upload expense receipts to Azure Blob Storage so that the pipeline can process them.", "size": "M", "days": 3, "acceptance_criteria": ["File upload API endpoint functional", "Files stored in Blob with metadata"], "dependencies": []},
                    {"id": "S1.2", "title": "As a developer, I want to extract fields from receipts using Azure Document Intelligence so that structured data is available for classification.", "size": "L", "days": 5, "acceptance_criteria": ["Amount, vendor, date extracted with >90% accuracy", "Fallback for unreadable documents"], "dependencies": ["S1.1"]},
                ],
            },
            {
                "id": "E2",
                "title": "Policy-Grounded Risk Classification",
                "description": "Classify expense claims as low/medium/high risk using GPT-4 with policy KB retrieval.",
                "sprint": 1,
                "stories": [
                    {"id": "S2.1", "title": "As a reviewer, I want each claim classified with a risk level so that I can prioritise my review queue.", "size": "L", "days": 6, "acceptance_criteria": ["Three-tier classification (low/medium/high)", "Policy reference included in explanation"], "dependencies": ["S1.2"]},
                    {"id": "S2.2", "title": "As a reviewer, I want a natural-language explanation for why a claim was flagged so that I understand the AI reasoning.", "size": "M", "days": 4, "acceptance_criteria": ["Explanation cites specific policy rule", "Confidence score shown"], "dependencies": ["S2.1"]},
                ],
            },
            {
                "id": "E3",
                "title": "Reviewer Dashboard & Human Approval",
                "description": "React dashboard for reviewers to approve, reject, or escalate flagged expense claims.",
                "sprint": 2,
                "stories": [
                    {"id": "S3.1", "title": "As a finance reviewer, I want to view my review queue sorted by risk so that I handle high-risk cases first.", "size": "M", "days": 4, "acceptance_criteria": ["Queue sorted by risk level", "Claim detail panel with explanation"], "dependencies": ["S2.1"]},
                    {"id": "S3.2", "title": "As a finance reviewer, I want approve/reject/escalate actions so that I can process each case with full auditability.", "size": "M", "days": 3, "acceptance_criteria": ["Three action buttons functional", "Decision logged with timestamp and reviewer ID"], "dependencies": ["S3.1"]},
                ],
            },
            {
                "id": "E4",
                "title": "Audit Trail & Reporting",
                "description": "Structured audit log and summary report for compliance and management.",
                "sprint": 2,
                "stories": [
                    {"id": "S4.1", "title": "As a compliance officer, I want an audit trail of all AI recommendations and reviewer decisions so that we can satisfy regulatory review.", "size": "M", "days": 3, "acceptance_criteria": ["Immutable log per case", "Exportable as CSV"], "dependencies": ["S3.2"]},
                ],
            },
        ],
        "sprint_summary": [
            {"sprint": 1, "goal": "End-to-end expense ingestion, OCR, and policy-grounded classification on one claim type.", "stories": ["S1.1", "S1.2", "S2.1", "S2.2"], "total_days": 18, "focus": "Core AI pipeline validation"},
            {"sprint": 2, "goal": "Reviewer dashboard with human approval actions and audit trail.", "stories": ["S3.1", "S3.2", "S4.1"], "total_days": 10, "focus": "Reviewer UX and compliance"},
        ],
        "risks": [
            "OCR accuracy may vary for low-quality receipt scans — need fallback manual entry",
            "Policy KB must be kept up-to-date; stale docs will degrade explanation quality",
            "Reviewer adoption risk if explanations are too verbose or technical",
        ],
        "open_items": [
            "Confirm whether invoice exception handling enters scope at Sprint 3",
            "Define auto-routing threshold for low-risk cases (confidence level required)",
        ],
        "total_sprints": 2,
        "confidence": "high",
    }
