"""
Orchestrator — runs the full agent pipeline in stage-gated order.
Runs in a background thread so Flask can serve SSE while agents are working.
"""
import threading
import time
import json
from services.session_state import SessionState
from services.preprocessor import preprocess_transcript
from agents import supervisor, policy_agent, kb_agent, web_research_agent, architecture_agent, business_agent, sprint_agent
from utils.llm_client import chat

SYNTHESIS_PROMPT = """You are a project planning supervisor. Consolidate all agent outputs into
a final Magic Meet Planning Board.

Return ONLY valid JSON:
{
  "project_title": "...",
  "problem_statement": "...",
  "scope_and_constraints": ["..."],
  "recommended_solution": "...",
  "architecture_summary": "...",
  "policy_considerations": ["..."],
  "roi_summary": "...",
  "sprint_overview": "...",
  "risks": ["..."],
  "next_steps": ["..."],
  "open_questions": ["..."]
}"""


def _synthesise_final_plan(session: SessionState) -> dict:
    session.update_agent("supervisor", status="running", task="Synthesising final planning board")

    context = {
        "meeting_summary": session.meeting_summary,
        "selected_architecture": session.artifacts.get("selected_arch", {}),
        "policy_hits": session.artifacts.get("policy_hits", []),
        "roi_scorecard": session.artifacts.get("roi_scorecard", {}),
        "sprint_backlog": {
            "total_sprints": session.artifacts.get("sprint_backlog", {}).get("total_sprints", 0),
            "sprint_goals": [s.get("goal") for s in session.artifacts.get("sprint_backlog", {}).get("sprint_summary", [])],
            "risks": session.artifacts.get("sprint_backlog", {}).get("risks", []),
        },
    }

    messages = [
        {"role": "system", "content": SYNTHESIS_PROMPT},
        {"role": "user", "content": json.dumps(context, indent=2)},
    ]

    try:
        raw = chat(messages, temperature=0.3, max_tokens=1500)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        plan = json.loads(raw)
    except Exception:
        plan = {
            "project_title": "AI-Assisted Finance Operations — Acme Capital",
            "problem_statement": session.meeting_summary.get("summary", ""),
            "scope_and_constraints": session.meeting_summary.get("constraints", []),
            "recommended_solution": "Azure Document Intelligence + GPT-4 + Human Approval Portal",
            "architecture_summary": session.artifacts.get("selected_arch", {}).get("summary", ""),
            "policy_considerations": [h.get("rule") for h in session.artifacts.get("policy_hits", [])],
            "roi_summary": session.artifacts.get("roi_scorecard", {}).get("summary", ""),
            "sprint_overview": "2 sprints: ingestion + classification (Sprint 1), reviewer UX + audit (Sprint 2)",
            "risks": session.artifacts.get("sprint_backlog", {}).get("risks", []),
            "next_steps": ["Finalise team assignments", "Set up Azure resource group", "Load policy docs to KB"],
            "open_questions": session.meeting_summary.get("open_questions", []),
        }

    session.artifacts["final_plan"] = plan
    session.push_event("artifact_update", {"type": "final_plan", "data": plan})
    session.update_agent("supervisor", status="done", task="Planning board ready", output="Final Magic Meet board generated.", confidence="high")
    return plan


class PipelineOrchestrator:
    def __init__(self, session: SessionState):
        self.session = session
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def run_async(self) -> None:
        self._thread = threading.Thread(target=self._run_pipeline, daemon=True)
        self._thread.start()

    def _run_pipeline(self) -> None:
        s = self.session
        try:
            # ── Preprocess ──
            s.stage = "preprocessing"
            s.push_event("stage_change", {"stage": "preprocessing"})
            s.meeting_summary = preprocess_transcript(s.full_transcript)
            s.push_event("meeting_summary", s.meeting_summary)

            # ── Supervisor classify ──
            s.stage = "stage0"
            supervisor.run(s)
            time.sleep(0.3)

            # ── Stage 1: Policy + KB (parallel via threads) ──
            s.stage = "stage1"
            s.push_event("stage_change", {"stage": "stage1"})

            t_policy = threading.Thread(target=policy_agent.run, args=(s,), daemon=True)
            t_kb = threading.Thread(target=kb_agent.run, args=(s,), daemon=True)
            t_policy.start()
            t_kb.start()
            t_policy.join()
            t_kb.join()

            # ── Checkpoint 1 ──
            s.stage = "checkpoint1"
            s.set_checkpoint_active("cp1")
            s.push_event("stage_change", {"stage": "checkpoint1"})
            self._wait_for_checkpoint("cp1")

            # ── Stage 2: Architecture + Web Research (parallel) ──
            s.stage = "stage2"
            s.push_event("stage_change", {"stage": "stage2"})

            t_web = threading.Thread(target=web_research_agent.run, args=(s,), daemon=True)
            t_arch = threading.Thread(target=architecture_agent.run, args=(s,), daemon=True)
            t_web.start()
            t_web.join()         # web must finish before arch (arch uses web findings)
            t_arch.start()
            t_arch.join()

            # ── Checkpoint 2 ──
            s.stage = "checkpoint2"
            s.set_checkpoint_active("cp2")
            s.push_event("stage_change", {"stage": "checkpoint2"})
            self._wait_for_checkpoint("cp2")

            # Set selected_arch from checkpoint
            cp2 = next((c for c in s.checkpoints if c.id == "cp2"), None)
            if cp2 and cp2.user_input.get("selected_option"):
                selected_id = cp2.user_input["selected_option"]
                for opt in s.artifacts.get("arch_options", []):
                    if opt.get("id") == selected_id:
                        s.artifacts["selected_arch"] = opt
                        break
            if not s.artifacts.get("selected_arch"):
                # Default to recommended
                for opt in s.artifacts.get("arch_options", []):
                    if opt.get("recommended"):
                        s.artifacts["selected_arch"] = opt
                        break

            # ── Stage 3: Business + Sprint (parallel) ──
            s.stage = "stage3"
            s.push_event("stage_change", {"stage": "stage3"})

            t_biz = threading.Thread(target=business_agent.run, args=(s,), daemon=True)
            t_sprint = threading.Thread(target=sprint_agent.run, args=(s,), daemon=True)
            t_biz.start()
            t_biz.join()        # sprint can use ROI context
            t_sprint.start()
            t_sprint.join()

            # ── Checkpoint 3 ──
            s.stage = "checkpoint3"
            s.set_checkpoint_active("cp3")
            s.push_event("stage_change", {"stage": "checkpoint3"})
            self._wait_for_checkpoint("cp3")

            # ── Synthesis ──
            s.stage = "synthesis"
            s.push_event("stage_change", {"stage": "synthesis"})
            _synthesise_final_plan(s)

            s.stage = "done"
            s.push_event("stage_change", {"stage": "done"})

        except Exception as e:
            s.push_event("error", {"message": str(e)})

    def _wait_for_checkpoint(self, cp_id: str, timeout: float = 300.0) -> None:
        """Block until the checkpoint is completed by the user or timeout."""
        elapsed = 0.0
        interval = 0.5
        while elapsed < timeout:
            if self._stop.is_set():
                return
            for cp in self.session.checkpoints:
                if cp.id == cp_id and cp.status == "completed":
                    return
            time.sleep(interval)
            elapsed += interval
        # Timeout — auto-continue with defaults
        self.session.complete_checkpoint(cp_id, {"auto": True})

    def stop(self) -> None:
        self._stop.set()
