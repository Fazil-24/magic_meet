import { AgentStatus } from "@/lib/types";
import clsx from "clsx";

export function StatusDot({ status }: { status: AgentStatus }) {
  return (
    <span
      className={clsx("inline-block w-2 h-2 rounded-full shrink-0", {
        "bg-gray-300": status === "idle",
        "bg-blue-500 animate-pulse": status === "running",
        "bg-green-500": status === "done",
        "bg-red-500": status === "error",
      })}
    />
  );
}
