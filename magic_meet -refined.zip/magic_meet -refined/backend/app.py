"""
Magic Meet — Flask backend
Endpoints:
  POST /api/session/create          → create new session
  POST /api/session/<id>/transcript → ingest a transcript chunk
  POST /api/session/<id>/start      → run pipeline (after enough transcript)
  POST /api/session/<id>/checkpoint → submit human checkpoint response
  GET  /api/session/<id>/stream     → SSE event stream
  GET  /api/session/<id>/state      → full session snapshot
  GET  /api/session/<id>/artifacts  → all artifacts
  POST /api/demo/load               → load sample transcript for demo
  GET  /api/audio/devices           → list audio input devices
  POST /api/audio/start             → start live audio capture
  POST /api/audio/stop              → stop live audio capture
"""
import json
import os
import time
import threading
from flask import Flask, jsonify, request, Response, stream_with_context
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

from services.session_state import create_session, get_session, get_or_create_demo_session, SessionState
from agents.orchestrator import PipelineOrchestrator

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-secret-key")
CORS(app, origins=[os.environ.get("FRONTEND_URL", "http://localhost:3000")], supports_credentials=True)

# Active orchestrators: session_id -> PipelineOrchestrator
_orchestrators: dict[str, PipelineOrchestrator] = {}

# Active audio session
_audio_session = None


# ──────────────────────────────────────────────
# Session endpoints
# ──────────────────────────────────────────────

@app.route("/api/session/create", methods=["POST"])
def create():
    s = create_session()
    return jsonify({"session_id": s.session_id}), 201


@app.route("/api/session/<session_id>/state", methods=["GET"])
def get_state(session_id: str):
    s = _resolve(session_id)
    if s is None:
        return jsonify({"error": "Session not found"}), 404
    return jsonify(s.to_dict())


@app.route("/api/session/<session_id>/artifacts", methods=["GET"])
def get_artifacts(session_id: str):
    s = _resolve(session_id)
    if s is None:
        return jsonify({"error": "Session not found"}), 404
    return jsonify(s.artifacts)


@app.route("/api/session/<session_id>/transcript", methods=["POST"])
def ingest_transcript(session_id: str):
    s = _resolve(session_id)
    if s is None:
        return jsonify({"error": "Session not found"}), 404
    body = request.get_json(force=True)
    speaker = body.get("speaker", "Unknown")
    text = body.get("text", "").strip()
    if not text:
        return jsonify({"error": "text is required"}), 400
    s.add_transcript_chunk(speaker, text)
    return jsonify({"ok": True, "chunks": len(s.transcript_chunks)})


@app.route("/api/session/<session_id>/start", methods=["POST"])
def start_pipeline(session_id: str):
    s = _resolve(session_id)
    if s is None:
        return jsonify({"error": "Session not found"}), 404
    if not s.full_transcript.strip():
        return jsonify({"error": "No transcript content yet"}), 400
    if session_id in _orchestrators and s.stage not in ("idle", "done"):
        return jsonify({"error": "Pipeline already running"}), 409

    orch = PipelineOrchestrator(s)
    _orchestrators[session_id] = orch
    orch.run_async()
    return jsonify({"ok": True, "stage": s.stage})


@app.route("/api/session/<session_id>/checkpoint", methods=["POST"])
def submit_checkpoint(session_id: str):
    s = _resolve(session_id)
    if s is None:
        return jsonify({"error": "Session not found"}), 404
    body = request.get_json(force=True)
    cp_id = body.get("checkpoint_id")
    user_input = body.get("user_input", {})
    if not cp_id:
        return jsonify({"error": "checkpoint_id required"}), 400
    s.complete_checkpoint(cp_id, user_input)
    return jsonify({"ok": True, "checkpoint_id": cp_id})


# ──────────────────────────────────────────────
# SSE stream
# ──────────────────────────────────────────────

@app.route("/api/session/<session_id>/stream")
def stream(session_id: str):
    s = _resolve(session_id)
    if s is None:
        return Response("data: {\"error\": \"not found\"}\n\n", mimetype="text/event-stream")

    def generate():
        yield _sse({"type": "connected", "session_id": session_id})
        while True:
            events = s.drain_events()
            for ev in events:
                yield _sse(ev)
            if s.stage == "done":
                yield _sse({"type": "done"})
                break
            time.sleep(0.3)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data)}\n\n"


# ──────────────────────────────────────────────
# Demo endpoint
# ──────────────────────────────────────────────

DEMO_TRANSCRIPT = [
    ("Riya", "We got the brief from Acme Capital. They want help with finance operations, especially employee expenses and vendor invoice exceptions. The main pain point is that reviewers spend too much time checking repetitive cases manually."),
    ("Arjun", "Yes, and they were clear that they do not want final approval to be automated. So the solution has to be decision support plus routing, not full autonomous approval."),
    ("Riya", "I think we should focus the MVP on expense review first because it is easier to explain in a demo and the documents are simpler than invoice exception flows."),
    ("Arjun", "That makes sense. We can ingest expense claims, read receipt images or PDFs, compare them against company policy, and classify the case as low, medium, or high risk."),
    ("Riya", "We should also make sure the model explains why it flagged something. The client specifically called out reviewer mistrust if the AI cannot explain its reasoning."),
    ("Arjun", "Right. So maybe the architecture is OCR plus document extraction, then a policy-grounded reasoning layer, then a reviewer dashboard with approve, reject, or escalate."),
    ("Riya", "I like that. But we also need to think about compliance. Client data cannot be used to train public models, and any recommendation must stay explainable."),
    ("Arjun", "Then Azure-native is probably the safest path. We can keep the knowledge base with policy docs and use retrieval during the reasoning step."),
    ("Riya", "Another question is ROI. If reviewers save even five minutes on a large chunk of low-risk cases, that could add up quickly. We should quantify that for the proposal."),
    ("Arjun", "For sprint planning, I would split it into ingestion and OCR, policy retrieval, risk classification, reviewer UI, and audit trail. Sprint 1 should validate ingestion plus policy-grounded review on one case type."),
    ("Riya", "Yes, and Sprint 2 can improve the user workflow and escalation paths. Let us have Magic Meet convert this into a proposed architecture, value summary, and sprint backlog."),
]


@app.route("/api/demo/load", methods=["POST"])
def load_demo():
    s = get_or_create_demo_session()
    # Reset if already done
    if s.stage == "done":
        from services.session_state import _sessions, SessionState
        from services.session_state import get_or_create_demo_session as _goc
        _sessions.pop("demo", None)
        s = _goc()

    for speaker, text in DEMO_TRANSCRIPT:
        s.add_transcript_chunk(speaker, text)

    return jsonify({"session_id": s.session_id, "chunks": len(s.transcript_chunks)})


@app.route("/api/demo/start", methods=["POST"])
def start_demo():
    s = get_or_create_demo_session()
    if "demo" in _orchestrators and s.stage not in ("idle", "done"):
        return jsonify({"ok": True, "already_running": True})

    orch = PipelineOrchestrator(s)
    _orchestrators["demo"] = orch
    orch.run_async()
    return jsonify({"ok": True, "session_id": "demo"})


# ──────────────────────────────────────────────
# Audio capture endpoints
# ──────────────────────────────────────────────

@app.route("/api/audio/devices", methods=["GET"])
def audio_devices():
    try:
        from services.audio_capture import list_audio_devices
        return jsonify(list_audio_devices())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/audio/start", methods=["POST"])
def audio_start():
    global _audio_session
    body = request.get_json(force=True) or {}
    session_id = body.get("session_id", "demo")
    s = _resolve(session_id)
    if s is None:
        return jsonify({"error": "Session not found"}), 404

    try:
        from services.audio_capture import AudioCaptureSession

        if _audio_session is not None:
            return jsonify({"error": "Audio already capturing"}), 409

        _audio_session = AudioCaptureSession()
        info = _audio_session.start()

        # Background thread: pull chunks and push to session
        def _feed():
            while True:
                chunk = _audio_session.get_chunk(timeout=0.5)
                if chunk is None:
                    continue
                s.add_transcript_chunk(chunk["speaker"], chunk["text"])

        threading.Thread(target=_feed, daemon=True).start()
        return jsonify({"ok": True, **info})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/audio/stop", methods=["POST"])
def audio_stop():
    global _audio_session
    if _audio_session is None:
        return jsonify({"error": "No active audio session"}), 400
    _audio_session.stop()
    _audio_session = None
    return jsonify({"ok": True})


# ──────────────────────────────────────────────
# Health check
# ──────────────────────────────────────────────

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "magic-meet-backend"})


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _resolve(session_id: str) -> SessionState | None:
    if session_id == "demo":
        return get_or_create_demo_session()
    return get_session(session_id)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "true").lower() == "true"
    app.run(host="0.0.0.0", port=port, debug=debug, threaded=True)
