"""
In-memory session state for a single meeting.
All agent outputs, transcript chunks, and checkpoint state live here.
"""
import uuid
from dataclasses import dataclass, field
from typing import Any
from datetime import datetime


@dataclass
class AgentState:
    name: str
    status: str = "idle"          # idle | running | done | error
    task: str = ""
    output: str = ""
    confidence: str = ""          # high | medium | low | warning
    artifacts: list[dict] = field(default_factory=list)
    updated_at: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status,
            "task": self.task,
            "output": self.output,
            "confidence": self.confidence,
            "artifacts": self.artifacts,
            "updated_at": self.updated_at,
        }


@dataclass
class CheckpointState:
    id: str
    title: str
    description: str
    status: str = "pending"       # pending | active | completed | skipped
    user_input: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "user_input": self.user_input,
        }


class SessionState:
    def __init__(self, session_id: str | None = None):
        self.session_id: str = session_id or str(uuid.uuid4())
        self.created_at: str = datetime.utcnow().isoformat()

        # Transcript
        self.transcript_chunks: list[dict] = []   # {speaker, text, timestamp}
        self.full_transcript: str = ""

        # Preprocessor output
        self.meeting_summary: dict = {}            # goals, constraints, risks, questions
        self.stage: str = "idle"                   # idle | preprocessing | stage1 | checkpoint1 | stage2 | checkpoint2 | stage3 | synthesis | done

        # Agents
        self.agents: dict[str, AgentState] = {
            "supervisor":    AgentState("supervisor"),
            "policy":        AgentState("policy"),
            "kb":            AgentState("kb"),
            "architecture":  AgentState("architecture"),
            "web_research":  AgentState("web_research"),
            "business":      AgentState("business"),
            "sprint":        AgentState("sprint"),
        }

        # Artifacts produced by agents
        self.artifacts: dict[str, Any] = {
            "policy_hits":      [],
            "kb_snippets":      [],
            "arch_options":     [],
            "selected_arch":    None,
            "roi_scorecard":    {},
            "sprint_backlog":   {},
            "final_plan":       {},
        }

        # Human checkpoints
        self.checkpoints: list[CheckpointState] = [
            CheckpointState("cp1", "Refine Constraints", "Review policy and KB findings. Add or adjust constraints before architecture analysis."),
            CheckpointState("cp2", "Select Architecture", "Choose one of the proposed architecture options for the solution."),
            CheckpointState("cp3", "Confirm Sprint Plan", "Review team capacity and adjust before sprint generation is finalised."),
        ]

        # SSE event queue (populated by agents, consumed by /stream endpoint)
        self._events: list[dict] = []

    def push_event(self, event_type: str, data: dict) -> None:
        self._events.append({"type": event_type, "data": data, "ts": datetime.utcnow().isoformat()})

    def drain_events(self) -> list[dict]:
        events, self._events = self._events, []
        return events

    def update_agent(self, name: str, **kwargs) -> None:
        agent = self.agents[name]
        for k, v in kwargs.items():
            setattr(agent, k, v)
        agent.updated_at = datetime.utcnow().isoformat()
        self.push_event("agent_update", agent.to_dict())

    def add_transcript_chunk(self, speaker: str, text: str) -> None:
        chunk = {"speaker": speaker, "text": text, "timestamp": datetime.utcnow().isoformat()}
        self.transcript_chunks.append(chunk)
        self.full_transcript += f"\n{speaker}: {text}"
        self.push_event("transcript_chunk", chunk)

    def set_checkpoint_active(self, cp_id: str) -> None:
        for cp in self.checkpoints:
            if cp.id == cp_id:
                cp.status = "active"
                self.push_event("checkpoint", cp.to_dict())

    def complete_checkpoint(self, cp_id: str, user_input: dict) -> None:
        for cp in self.checkpoints:
            if cp.id == cp_id:
                cp.status = "completed"
                cp.user_input = user_input
                self.push_event("checkpoint", cp.to_dict())

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "stage": self.stage,
            "meeting_summary": self.meeting_summary,
            "agents": {k: v.to_dict() for k, v in self.agents.items()},
            "artifacts": self.artifacts,
            "checkpoints": [c.to_dict() for c in self.checkpoints],
            "transcript_count": len(self.transcript_chunks),
        }


# Global registry: session_id -> SessionState
_sessions: dict[str, SessionState] = {}


def create_session() -> SessionState:
    s = SessionState()
    _sessions[s.session_id] = s
    return s


def get_session(session_id: str) -> SessionState | None:
    return _sessions.get(session_id)


def get_or_create_demo_session() -> SessionState:
    """Returns the single demo session (creates if missing)."""
    if "demo" not in _sessions:
        s = SessionState("demo")
        _sessions["demo"] = s
    return _sessions["demo"]
