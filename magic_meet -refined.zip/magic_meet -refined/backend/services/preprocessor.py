"""
Converts raw transcript text into a structured meeting summary.
Runs as a lightweight LLM call — cheap and fast.
"""
import json
from utils.llm_client import chat

SYSTEM_PROMPT = """You are a meeting analyst. Given a raw transcript, extract structured information.
Return ONLY valid JSON with this exact schema:
{
  "goals": ["..."],
  "constraints": ["..."],
  "risks": ["..."],
  "open_questions": ["..."],
  "proposed_solutions": ["..."],
  "key_decisions": ["..."],
  "participants": ["..."],
  "summary": "2-3 sentence plain English summary"
}
Be concise. Use the actual content from the transcript — do not hallucinate."""


def preprocess_transcript(transcript: str) -> dict:
    if not transcript.strip():
        return _empty_summary()

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Transcript:\n{transcript}"},
    ]

    try:
        raw = chat(messages, temperature=0.1, max_tokens=1000)
        # Strip markdown code fences if present
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw)
    except Exception:
        return _empty_summary()


def _empty_summary() -> dict:
    return {
        "goals": [],
        "constraints": [],
        "risks": [],
        "open_questions": [],
        "proposed_solutions": [],
        "key_decisions": [],
        "participants": [],
        "summary": "",
    }
