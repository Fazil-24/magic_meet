"""
Windows audio capture for Magic Meet.

Two streams:
  1. VB-CABLE Output  — captures Zoom / meeting audio (other participants)
  2. Default microphone — captures local speaker

Both are transcribed by faster-whisper (medium model) and merged with speaker tags.

Setup required:
  1. Install VB-CABLE from https://vb-audio.com/Cable/
  2. In Windows Sound settings, set Zoom speaker output to "CABLE Input (VB-Audio Virtual Cable)"
  3. Run: pip install faster-whisper sounddevice numpy scipy
  4. Download the medium model on first run (happens automatically ~1.5 GB)
"""
import threading
import queue
import time
import numpy as np
import sounddevice as sd
from faster_whisper import WhisperModel

SAMPLE_RATE = 16000
CHUNK_SECONDS = 10          # transcribe every N seconds
MODEL_SIZE = "medium"

_model: WhisperModel | None = None
_transcript_queue: queue.Queue = queue.Queue()


def _get_model() -> WhisperModel:
    global _model
    if _model is None:
        # Downloads to ~/.cache/huggingface on first run
        _model = WhisperModel(MODEL_SIZE, device="cpu", compute_type="int8")
    return _model


def _find_device(name_fragment: str) -> int | None:
    """Return device index whose name contains name_fragment (case-insensitive)."""
    devices = sd.query_devices()
    for i, d in enumerate(devices):
        if name_fragment.lower() in d["name"].lower() and d["max_input_channels"] > 0:
            return i
    return None


def _record_and_transcribe(device_index: int | None, label: str, stop_event: threading.Event) -> None:
    model = _get_model()
    buffer: list[np.ndarray] = []
    chunk_frames = SAMPLE_RATE * CHUNK_SECONDS

    def callback(indata, frames, time_info, status):
        buffer.append(indata[:, 0].copy())

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype="float32",
        device=device_index,
        callback=callback,
        blocksize=1024,
    ):
        while not stop_event.is_set():
            time.sleep(CHUNK_SECONDS)
            if not buffer:
                continue
            audio = np.concatenate(buffer)
            buffer.clear()

            # Skip near-silent chunks
            if np.abs(audio).mean() < 0.005:
                continue

            segments, _ = model.transcribe(audio, language="en", beam_size=5)
            text = " ".join(s.text.strip() for s in segments).strip()
            if text:
                _transcript_queue.put({"speaker": label, "text": text})


class AudioCaptureSession:
    def __init__(self):
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []

    def start(self) -> dict:
        """Start capturing. Returns info about detected devices."""
        vbcable_idx = _find_device("cable output")
        mic_idx = None  # None = system default mic

        t1 = threading.Thread(
            target=_record_and_transcribe,
            args=(vbcable_idx, "Meeting", self._stop),
            daemon=True,
        )
        t2 = threading.Thread(
            target=_record_and_transcribe,
            args=(mic_idx, "You", self._stop),
            daemon=True,
        )
        t1.start()
        t2.start()
        self._threads = [t1, t2]

        return {
            "vbcable_device": vbcable_idx,
            "mic_device": mic_idx,
            "status": "started",
        }

    def stop(self) -> None:
        self._stop.set()
        for t in self._threads:
            t.join(timeout=3)

    def get_chunk(self, timeout: float = 0.1) -> dict | None:
        try:
            return _transcript_queue.get(timeout=timeout)
        except queue.Empty:
            return None


def list_audio_devices() -> list[dict]:
    """Returns all input devices — useful for debugging."""
    devices = sd.query_devices()
    return [
        {"index": i, "name": d["name"], "channels": d["max_input_channels"]}
        for i, d in enumerate(devices)
        if d["max_input_channels"] > 0
    ]
