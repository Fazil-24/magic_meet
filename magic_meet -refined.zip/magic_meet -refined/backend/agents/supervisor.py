"""
Supervisor Agent — reads meeting state, decides stage, orchestrates specialist agents.
"""
import json
from utils.llm_client import chat
from services.session_state import SessionState

SYSTEM_PROMPT = """You are a senior project planning supervisor AI. You receive a structured meeting summary
and decide the current planning stage plus what the main project objective is.

Return ONLY valid JSON:
{
  "planning_stage": "brainstorming|narrowing|planning",
  "project_objective": "one sentence",
  "primary_domain": "finance|healthcare|retail|general",
  "key_decision_needed": "the most important unresolved decision",
  "ready_for_agents": true
}"""


def run(session: SessionState) -> dict:
    session.update_agent(
        "supervisor",
        status="running",
        task="Analysing meeting context and classifying planning stage",
        confidence="",
    )

    summary = session.meeting_summary
    if not summary or not summary.get("goals"):
        session.update_agent("supervisor", status="idle", task="Waiting for transcript content")
        return {}

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Meeting summary:\n{json.dumps(summary, indent=2)}"},
    ]

    try:
        raw = chat(messages, temperature=0.2, max_tokens=400)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception as e:
        result = {
            "planning_stage": "brainstorming",
            "project_objective": summary.get("summary", ""),
            "primary_domain": "general",
            "key_decision_needed": summary.get("open_questions", [""])[0],
            "ready_for_agents": True,
        }

    session.update_agent(
        "supervisor",
        status="done",
        task="Stage classified",
        output=f"Stage: {result.get('planning_stage', 'unknown').title()}\n{result.get('project_objective', '')}",
        confidence="high",
    )
    session.artifacts["supervisor_analysis"] = result
    return result
