export type AgentStatus = "idle" | "running" | "done" | "error";
export type Confidence = "high" | "medium" | "low" | "warning" | "";
export type CheckpointStatus = "pending" | "active" | "completed" | "skipped";
export type Stage =
  | "idle" | "preprocessing" | "stage0"
  | "stage1" | "checkpoint1"
  | "stage2" | "checkpoint2"
  | "stage3" | "checkpoint3"
  | "synthesis" | "done";

export interface AgentState {
  name: string;
  status: AgentStatus;
  task: string;
  output: string;
  confidence: Confidence;
  artifacts: unknown[];
  updated_at: string;
}

export interface CheckpointState {
  id: string;
  title: string;
  description: string;
  status: CheckpointStatus;
  user_input: Record<string, unknown>;
}

export interface TranscriptChunk {
  speaker: string;
  text: string;
  timestamp: string;
}

export interface MeetingSummary {
  goals: string[];
  constraints: string[];
  risks: string[];
  open_questions: string[];
  proposed_solutions: string[];
  key_decisions: string[];
  participants: string[];
  summary: string;
}

export interface PolicyHit {
  rule: string;
  status: "pass" | "warn" | "fail";
  note: string;
}

export interface KBSnippet {
  source: string;
  relevance: "high" | "medium" | "low";
  content: string;
  implication: string;
}

export interface ArchOption {
  id: string;
  title: string;
  summary: string;
  components: string[];
  pros: string[];
  cons: string[];
  effort: "low" | "medium" | "high";
  compliance_confidence: "high" | "medium" | "low";
  recommended: boolean;
}

export interface RoiScorecard {
  assumptions: string[];
  time_savings: Record<string, number>;
  cost_estimate: Record<string, number>;
  roi: { annual_value_usd: number; payback_months: number; band: string };
  scoring: Record<string, number>;
  summary: string;
  confidence: Confidence;
}

export interface SprintEpic {
  id: string;
  title: string;
  description: string;
  sprint: number;
  stories: Array<{
    id: string;
    title: string;
    size: string;
    days: number;
    acceptance_criteria: string[];
    dependencies: string[];
  }>;
}

export interface SprintBacklog {
  epics: SprintEpic[];
  sprint_summary: Array<{ sprint: number; goal: string; stories: string[]; total_days: number; focus: string }>;
  risks: string[];
  open_items: string[];
  total_sprints: number;
  confidence: Confidence;
}

export interface FinalPlan {
  project_title: string;
  problem_statement: string;
  scope_and_constraints: string[];
  recommended_solution: string;
  architecture_summary: string;
  policy_considerations: string[];
  roi_summary: string;
  sprint_overview: string;
  risks: string[];
  next_steps: string[];
  open_questions: string[];
}

export interface SessionState {
  session_id: string;
  created_at: string;
  stage: Stage;
  meeting_summary: MeetingSummary;
  agents: Record<string, AgentState>;
  artifacts: {
    policy_hits: PolicyHit[];
    kb_snippets: KBSnippet[];
    arch_options: ArchOption[];
    selected_arch: ArchOption | null;
    roi_scorecard: RoiScorecard | Record<string, never>;
    sprint_backlog: SprintBacklog | Record<string, never>;
    final_plan: FinalPlan | Record<string, never>;
  };
  checkpoints: CheckpointState[];
  transcript_count: number;
}

export interface SSEEvent {
  type: string;
  data?: unknown;
  ts?: string;
  session_id?: string;
  stage?: string;
  message?: string;
}
