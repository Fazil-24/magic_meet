"""
Policy / Compliance Agent — checks the solution idea against Neural Systems guardrails.
Uses the KB (Azure AI Search) if available; falls back to embedded policy text.
"""
import json
import os
from utils.llm_client import chat
from services.session_state import SessionState

# Embedded fallback — extracted from magic_meet_policy_guardrails.docx
EMBEDDED_POLICY = """
NEURAL SYSTEMS AI POLICY GUARDRAILS (summary):
- Every AI workflow must preserve a human review path for high-impact decisions.
- PII must not be used for model training without legal/security/client approval.
- Financial transaction data is confidential by default.
- Foundation models via approved enterprise platforms only.
- High-risk outputs (financial recommendations, compliance decisions) require human approval before execution.
- Agents may draft plans but final approval stays with a human project owner.
- Prefer modular architecture: ingestion | orchestration | retrieval | reasoning | output.
- Secrets never in source code. Least-privilege access. Logs must not store raw sensitive financial values.
- Any agent with write access to downstream tools must operate behind approval gates.
- Do not present AI outputs as investment advice.
- Do not automate final approval for credit, underwriting, or treasury actions.
- ROI estimates must include explicit assumptions.
- Risk scoring must be labeled as decision support, not a final decision.
- Policy review must run before final architecture approval.
"""

SYSTEM_PROMPT = """You are a compliance and policy review agent for Neural Systems.
Your job is to evaluate a proposed solution against company guardrails and flag any concerns.

Return ONLY valid JSON:
{
  "policy_hits": [
    {"rule": "rule text", "status": "pass|warn|fail", "note": "brief explanation"}
  ],
  "overall_status": "pass|warn|fail",
  "blocking_issues": ["..."],
  "recommendations": ["..."],
  "confidence": "high|medium|low"
}"""


def _search_kb(query: str) -> str:
    """Query Azure AI Search index. Returns empty string if not configured."""
    try:
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential

        endpoint = os.environ.get("AZURE_SEARCH_ENDPOINT", "")
        api_key = os.environ.get("AZURE_SEARCH_API_KEY", "")
        index = os.environ.get("AZURE_SEARCH_INDEX", "magic-meet-kb")

        if not endpoint or not api_key or "YOUR_" in endpoint:
            return ""

        client = SearchClient(endpoint, index, AzureKeyCredential(api_key))
        results = client.search(query, top=3)
        snippets = []
        for r in results:
            content = r.get("content", r.get("chunk", ""))
            if content:
                snippets.append(content[:500])
        return "\n\n".join(snippets)
    except Exception:
        return ""


def run(session: SessionState) -> dict:
    session.update_agent(
        "policy",
        status="running",
        task="Checking solution against Neural Systems guardrails",
        confidence="",
    )

    summary = session.meeting_summary
    proposed = summary.get("proposed_solutions", [])
    constraints = summary.get("constraints", [])

    kb_snippets = _search_kb("AI policy guardrails compliance finance")
    policy_context = kb_snippets if kb_snippets else EMBEDDED_POLICY

    user_content = (
        f"Proposed solutions:\n{json.dumps(proposed, indent=2)}\n\n"
        f"Stated constraints:\n{json.dumps(constraints, indent=2)}\n\n"
        f"Policy reference:\n{policy_context}"
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_content},
    ]

    try:
        raw = chat(messages, temperature=0.1, max_tokens=1200)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception:
        result = {
            "policy_hits": [{"rule": "Human approval required for financial decisions", "status": "warn", "note": "Ensure no automated final approval"}],
            "overall_status": "warn",
            "blocking_issues": [],
            "recommendations": ["Ensure human-in-the-loop for all financial decisions"],
            "confidence": "medium",
        }

    # Store artifacts
    session.artifacts["policy_hits"] = result.get("policy_hits", [])
    session.push_event("artifact_update", {"type": "policy_hits", "data": result.get("policy_hits", [])})

    overall = result.get("overall_status", "warn")
    confidence_map = {"pass": "high", "warn": "medium", "fail": "warning"}

    session.update_agent(
        "policy",
        status="done",
        task="Policy review complete",
        output=f"Overall: {overall.upper()} — {len(result.get('blocking_issues', []))} blocking issues, "
               f"{len(result.get('recommendations', []))} recommendations",
        confidence=confidence_map.get(overall, "medium"),
        artifacts=result.get("policy_hits", []),
    )
    return result
