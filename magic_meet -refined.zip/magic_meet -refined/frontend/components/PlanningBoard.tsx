"use client";
import { FinalPlan } from "@/lib/types";
import { FileText, Target, CheckCircle2, Code2, ShieldCheck, TrendingUp, CalendarDays, AlertTriangle, HelpCircle, ArrowRight } from "lucide-react";

interface Props {
  plan: FinalPlan;
}

export default function PlanningBoard({ plan }: Props) {
  if (!plan?.project_title) return null;

  return (
    <div className="fixed inset-0 bg-gray-50 z-40 overflow-y-auto">
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <CheckCircle2 size={16} />
            Planning Board Ready
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{plan.project_title}</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">{plan.problem_statement}</p>
        </div>

        {/* Two-column grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Recommended Solution */}
          <BoardCard
            icon={<Target size={16} className="text-brand-600" />}
            title="Recommended Solution"
            colSpan={true}
          >
            <p className="text-sm text-gray-700 leading-relaxed">{plan.recommended_solution}</p>
          </BoardCard>

          {/* Architecture */}
          <BoardCard icon={<Code2 size={16} className="text-brand-600" />} title="Architecture Summary">
            <p className="text-sm text-gray-700 leading-relaxed">{plan.architecture_summary}</p>
          </BoardCard>

          {/* Policy */}
          <BoardCard icon={<ShieldCheck size={16} className="text-brand-600" />} title="Policy Considerations">
            <ListItems items={plan.policy_considerations} />
          </BoardCard>

          {/* ROI */}
          <BoardCard icon={<TrendingUp size={16} className="text-brand-600" />} title="ROI Summary">
            <p className="text-sm text-gray-700 leading-relaxed">{plan.roi_summary}</p>
          </BoardCard>

          {/* Sprint */}
          <BoardCard icon={<CalendarDays size={16} className="text-brand-600" />} title="Sprint Overview">
            <p className="text-sm text-gray-700 leading-relaxed">{plan.sprint_overview}</p>
          </BoardCard>

          {/* Scope */}
          <BoardCard icon={<FileText size={16} className="text-brand-600" />} title="Scope & Constraints">
            <ListItems items={plan.scope_and_constraints} />
          </BoardCard>

          {/* Risks */}
          <BoardCard icon={<AlertTriangle size={16} className="text-amber-500" />} title="Risks">
            <ListItems items={plan.risks} bullet="⚠" />
          </BoardCard>

          {/* Next Steps */}
          <BoardCard icon={<ArrowRight size={16} className="text-green-600" />} title="Next Steps">
            <ol className="space-y-1.5">
              {plan.next_steps?.map((step, i) => (
                <li key={i} className="flex gap-2 text-sm text-gray-700">
                  <span className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-xs font-semibold shrink-0">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </BoardCard>

          {/* Open Questions */}
          {plan.open_questions?.length > 0 && (
            <BoardCard icon={<HelpCircle size={16} className="text-gray-500" />} title="Open Questions" colSpan={true}>
              <ListItems items={plan.open_questions} bullet="?" className="text-gray-500" />
            </BoardCard>
          )}
        </div>
      </div>
    </div>
  );
}

function BoardCard({
  icon, title, children, colSpan,
}: {
  icon: React.ReactNode; title: string; children: React.ReactNode; colSpan?: boolean;
}) {
  return (
    <div className={`card ${colSpan ? "md:col-span-2" : ""}`}>
      <div className="card-header">
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-semibold text-gray-800 text-sm">{title}</span>
        </div>
      </div>
      <div className="card-body">{children}</div>
    </div>
  );
}

function ListItems({
  items = [], bullet = "•", className = "text-gray-700",
}: {
  items: string[]; bullet?: string; className?: string;
}) {
  if (!items.length) return <p className="text-sm text-gray-400">None</p>;
  return (
    <ul className="space-y-1.5">
      {items.map((item, i) => (
        <li key={i} className={`flex gap-2 text-sm ${className}`}>
          <span className="shrink-0">{bullet}</span>
          {item}
        </li>
      ))}
    </ul>
  );
}
