"use client";
import { SessionState } from "@/lib/types";
import { FileText, ShieldCheck, Database, Code2, TrendingUp, CalendarDays, CheckCircle2, XCircle, AlertCircle } from "lucide-react";

interface Props {
  artifacts: SessionState["artifacts"];
  stage: SessionState["stage"];
}

export default function ArtifactsPane({ artifacts, stage }: Props) {
  const { policy_hits, kb_snippets, arch_options, roi_scorecard, sprint_backlog, final_plan } = artifacts;

  return (
    <div className="pane">
      <div className="pane-header">
        <div className="flex items-center gap-2">
          <FileText size={15} className="text-brand-600" />
          <span className="font-semibold text-gray-800">Artifacts</span>
        </div>
      </div>

      <div className="pane-body">
        {/* Policy Hits */}
        {policy_hits?.length > 0 && (
          <Section title="Policy Review" icon={<ShieldCheck size={13} className="text-brand-600" />}>
            {policy_hits.map((hit, i) => (
              <div key={i} className="flex gap-2 items-start py-1.5 border-b border-gray-50 last:border-0">
                <PolicyIcon status={hit.status} />
                <div className="min-w-0">
                  <p className="text-xs font-medium text-gray-800 leading-snug">{hit.rule}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{hit.note}</p>
                </div>
              </div>
            ))}
          </Section>
        )}

        {/* KB Snippets */}
        {kb_snippets?.length > 0 && (
          <Section title="Knowledge Retrieved" icon={<Database size={13} className="text-brand-600" />}>
            {kb_snippets.slice(0, 4).map((s, i) => (
              <div key={i} className="py-1.5 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className={`badge ${s.relevance === "high" ? "badge-blue" : "badge-gray"}`}>{s.relevance}</span>
                  <span className="text-xs font-medium text-gray-700">{s.source}</span>
                </div>
                <p className="text-xs text-gray-600 line-clamp-2">{s.content}</p>
                {s.implication && <p className="text-xs text-brand-600 mt-0.5 italic">{s.implication}</p>}
              </div>
            ))}
          </Section>
        )}

        {/* Architecture Options */}
        {arch_options?.length > 0 && (
          <Section title="Architecture Options" icon={<Code2 size={13} className="text-brand-600" />}>
            {arch_options.map((opt) => (
              <div
                key={opt.id}
                className={`rounded-md p-2.5 mb-2 border text-xs ${
                  opt.recommended
                    ? "border-brand-300 bg-brand-50"
                    : "border-gray-200 bg-white"
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-1">
                  <span className="font-semibold text-gray-800">{opt.title}</span>
                  {opt.recommended && <span className="badge badge-blue shrink-0">Recommended</span>}
                </div>
                <p className="text-gray-600 leading-relaxed">{opt.summary}</p>
                <div className="mt-1.5 flex gap-2 flex-wrap">
                  <span className={`badge ${opt.effort === "low" ? "badge-green" : opt.effort === "medium" ? "badge-yellow" : "badge-red"}`}>
                    Effort: {opt.effort}
                  </span>
                  <span className={`badge ${opt.compliance_confidence === "high" ? "badge-green" : "badge-yellow"}`}>
                    Compliance: {opt.compliance_confidence}
                  </span>
                </div>
              </div>
            ))}
          </Section>
        )}

        {/* ROI Scorecard */}
        {"roi" in roi_scorecard && (roi_scorecard as { roi?: { payback_months: number; band: string; annual_value_usd: number } }).roi && (
          <Section title="ROI Scorecard" icon={<TrendingUp size={13} className="text-brand-600" />}>
            <ROICard scorecard={roi_scorecard as import("@/lib/types").RoiScorecard} />
          </Section>
        )}

        {/* Sprint Backlog */}
        {"epics" in sprint_backlog && (sprint_backlog as { epics?: unknown[] }).epics?.length && (
          <Section title="Sprint Backlog" icon={<CalendarDays size={13} className="text-brand-600" />}>
            <SprintCard backlog={sprint_backlog as import("@/lib/types").SprintBacklog} />
          </Section>
        )}

        {/* Empty state */}
        {!policy_hits?.length && !kb_snippets?.length && !arch_options?.length && (
          <div className="text-center py-12">
            <FileText size={28} className="text-gray-300 mx-auto mb-2" />
            <p className="text-xs text-gray-400">Agent outputs will appear here as they complete.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="card overflow-hidden">
      <div className="card-header">
        <div className="flex items-center gap-1.5">
          {icon}
          <span className="section-title">{title}</span>
        </div>
      </div>
      <div className="card-body">{children}</div>
    </div>
  );
}

function PolicyIcon({ status }: { status: string }) {
  if (status === "pass") return <CheckCircle2 size={13} className="text-green-500 shrink-0 mt-0.5" />;
  if (status === "fail") return <XCircle size={13} className="text-red-500 shrink-0 mt-0.5" />;
  return <AlertCircle size={13} className="text-amber-500 shrink-0 mt-0.5" />;
}

function ROICard({ scorecard }: { scorecard: import("@/lib/types").RoiScorecard }) {
  const { roi, scoring, summary, assumptions } = scorecard;
  const bandColor = roi?.band === "strong" ? "badge-green" : roi?.band === "moderate" ? "badge-yellow" : "badge-red";

  return (
    <div className="space-y-3 text-xs">
      <div className="grid grid-cols-3 gap-2">
        <Stat label="Annual Value" value={`$${(roi?.annual_value_usd ?? 0).toLocaleString()}`} />
        <Stat label="Payback" value={`${roi?.payback_months ?? "?"} mo`} />
        <div className="text-center">
          <p className="text-gray-500 mb-1">Band</p>
          <span className={`badge ${bandColor}`}>{roi?.band ?? "—"}</span>
        </div>
      </div>

      {scoring && Object.keys(scoring).length > 0 && (
        <div>
          <p className="section-title mb-1.5">Solution Scoring (1–5)</p>
          <div className="grid grid-cols-2 gap-1">
            {Object.entries(scoring).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between bg-gray-50 rounded px-2 py-1">
                <span className="text-gray-600 capitalize">{k.replace(/_/g, " ")}</span>
                <ScoreDots score={v} />
              </div>
            ))}
          </div>
        </div>
      )}

      {summary && <p className="text-gray-600 italic leading-relaxed">{summary}</p>}

      {assumptions?.length > 0 && (
        <details className="text-gray-500">
          <summary className="cursor-pointer section-title">Assumptions ({assumptions.length})</summary>
          <ul className="mt-1 space-y-0.5 list-disc list-inside">
            {assumptions.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </details>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <p className="text-gray-500 mb-0.5 text-xs">{label}</p>
      <p className="font-semibold text-gray-800">{value}</p>
    </div>
  );
}

function ScoreDots({ score }: { score: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <div
          key={i}
          className={`w-2 h-2 rounded-full ${i <= score ? "bg-brand-500" : "bg-gray-200"}`}
        />
      ))}
    </div>
  );
}

function SprintCard({ backlog }: { backlog: import("@/lib/types").SprintBacklog }) {
  const { epics, sprint_summary, risks, total_sprints } = backlog;

  return (
    <div className="space-y-3 text-xs">
      <div className="flex gap-2 flex-wrap">
        <span className="badge badge-blue">{total_sprints} Sprints</span>
        <span className="badge badge-gray">{epics?.length ?? 0} Epics</span>
        <span className="badge badge-gray">{epics?.reduce((s, e) => s + (e.stories?.length ?? 0), 0) ?? 0} Stories</span>
      </div>

      {sprint_summary?.map((s) => (
        <div key={s.sprint} className="bg-gray-50 rounded p-2 border border-gray-100">
          <p className="font-medium text-gray-800 mb-0.5">Sprint {s.sprint} — {s.focus}</p>
          <p className="text-gray-600">{s.goal}</p>
          <p className="text-gray-400 mt-0.5">{s.total_days} delivery days</p>
        </div>
      ))}

      {epics?.map((epic) => (
        <details key={epic.id} className="border border-gray-100 rounded">
          <summary className="p-2 cursor-pointer font-medium text-gray-700 hover:bg-gray-50">
            {epic.id}: {epic.title} <span className="text-gray-400">(Sprint {epic.sprint})</span>
          </summary>
          <div className="px-2 pb-2 space-y-1 mt-1">
            {epic.stories?.map((story) => (
              <div key={story.id} className="bg-gray-50 rounded p-1.5 border border-gray-100">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-gray-700 leading-snug">{story.title}</p>
                  <span className={`badge shrink-0 ${story.size === "L" ? "badge-red" : story.size === "M" ? "badge-yellow" : "badge-green"}`}>
                    {story.size}
                  </span>
                </div>
                <p className="text-gray-400 mt-0.5">{story.days}d</p>
              </div>
            ))}
          </div>
        </details>
      ))}

      {risks?.length > 0 && (
        <div>
          <p className="section-title mb-1">Risks</p>
          {risks.map((r, i) => (
            <div key={i} className="flex gap-1.5 text-gray-600 py-0.5">
              <AlertCircle size={11} className="text-amber-500 shrink-0 mt-0.5" />
              {r}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
