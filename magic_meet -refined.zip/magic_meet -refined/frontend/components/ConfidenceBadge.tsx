import { Confidence } from "@/lib/types";
import clsx from "clsx";

const MAP: Record<string, { label: string; cls: string }> = {
  high:    { label: "High",    cls: "badge badge-green" },
  medium:  { label: "Medium",  cls: "badge badge-yellow" },
  low:     { label: "Low",     cls: "badge badge-gray" },
  warning: { label: "Warning", cls: "badge badge-red" },
};

export function ConfidenceBadge({ confidence }: { confidence: Confidence }) {
  if (!confidence) return null;
  const { label, cls } = MAP[confidence] ?? { label: confidence, cls: "badge badge-gray" };
  return <span className={cls}>{label}</span>;
}
