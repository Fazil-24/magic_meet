"""
Web Research Agent — performs focused DuckDuckGo searches grounded in the project context.
Only runs after Policy + KB agents have produced results.
"""
import json
from utils.llm_client import chat
from services.session_state import SessionState

QUERY_GEN_PROMPT = """You are a technical research agent. Based on the project context, generate
3-4 focused web search queries that will find the best architecture patterns and technology choices.
Queries must be specific and grounded in the stated constraints.

Return ONLY valid JSON: {"queries": ["query1", "query2", "query3"]}"""

SYNTHESIS_PROMPT = """You are a technical research analyst. Synthesise the search results below
into actionable technology insights for the project.

Return ONLY valid JSON:
{
  "findings": [
    {"topic": "...", "insight": "...", "relevance": "high|medium|low"}
  ],
  "recommended_patterns": ["..."],
  "confidence": "high|medium|low"
}"""


def _ddg_search(query: str, max_results: int = 4) -> list[dict]:
    """DuckDuckGo search using duckduckgo-search package (no API key needed)."""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        return [{"title": r.get("title", ""), "body": r.get("body", ""), "href": r.get("href", "")} for r in results]
    except Exception:
        return []


def run(session: SessionState) -> dict:
    session.update_agent(
        "web_research",
        status="running",
        task="Generating focused search queries from project context",
        confidence="",
    )

    summary = session.meeting_summary
    policy_hits = session.artifacts.get("policy_hits", [])
    kb_snippets = session.artifacts.get("kb_snippets", [])

    context = {
        "goals": summary.get("goals", []),
        "constraints": summary.get("constraints", []),
        "proposed_solutions": summary.get("proposed_solutions", []),
        "policy_concerns": [h.get("rule", "") for h in policy_hits if h.get("status") in ("warn", "fail")],
        "kb_key_topics": [s.get("topic", s.get("source", "")) for s in kb_snippets[:3]],
    }

    # Generate queries
    messages = [
        {"role": "system", "content": QUERY_GEN_PROMPT},
        {"role": "user", "content": f"Project context:\n{json.dumps(context, indent=2)}"},
    ]

    try:
        raw = chat(messages, temperature=0.3, max_tokens=300)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        queries = json.loads(raw).get("queries", [])
    except Exception:
        queries = [
            "Azure AI document intelligence expense review human-in-the-loop",
            "policy grounded LLM finance operations architecture",
            "human approval workflow Azure AI finance compliance",
        ]

    session.update_agent("web_research", task=f"Searching: {queries[0][:60]}...")

    # Run searches
    all_results: list[dict] = []
    for query in queries[:3]:
        results = _ddg_search(query, max_results=3)
        all_results.extend(results)

    if not all_results:
        session.update_agent(
            "web_research",
            status="done",
            task="Search complete (no results)",
            output="No web results retrieved. Architecture will be based on internal knowledge.",
            confidence="low",
        )
        return {"findings": [], "recommended_patterns": [], "confidence": "low"}

    # Synthesise
    results_text = "\n\n".join(
        f"[{r['title']}]\n{r['body'][:400]}" for r in all_results[:8]
    )
    messages = [
        {"role": "system", "content": SYNTHESIS_PROMPT},
        {"role": "user", "content": f"Project context:\n{json.dumps(context, indent=2)}\n\nSearch results:\n{results_text}"},
    ]

    try:
        raw = chat(messages, temperature=0.2, max_tokens=1000)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception:
        result = {
            "findings": [{"topic": "Azure AI", "insight": "Azure Document Intelligence + Azure OpenAI is a proven pattern for finance document review.", "relevance": "high"}],
            "recommended_patterns": ["Azure Document Intelligence + GPT-4 reasoning + human review dashboard"],
            "confidence": "medium",
        }

    session.artifacts["web_findings"] = result.get("findings", [])
    session.push_event("artifact_update", {"type": "web_findings", "data": result.get("findings", [])})

    session.update_agent(
        "web_research",
        status="done",
        task="Web research complete",
        output=f"Found {len(result.get('findings', []))} insights. Recommended: {result.get('recommended_patterns', [''])[0][:80]}",
        confidence=result.get("confidence", "medium"),
        artifacts=result.get("findings", []),
    )
    return result
