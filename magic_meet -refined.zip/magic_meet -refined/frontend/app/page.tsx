"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import {
  SessionState, TranscriptChunk, MeetingSummary,
  CheckpointState, ArchOption, FinalPlan, SSEEvent, Stage,
} from "@/lib/types";
import { api, createSSE } from "@/lib/api";

import LiveTranscript from "@/components/LiveTranscript";
import AgentKitchen from "@/components/AgentKitchen";
import ArtifactsPane from "@/components/ArtifactsPane";
import CheckpointModal from "@/components/CheckpointModal";
import PlanningBoard from "@/components/PlanningBoard";

import { Play, Mic, MicOff, RefreshCw, LayoutDashboard, Loader2 } from "lucide-react";
import clsx from "clsx";

const EMPTY_SUMMARY: MeetingSummary = {
  goals: [], constraints: [], risks: [], open_questions: [],
  proposed_solutions: [], key_decisions: [], participants: [], summary: "",
};

const EMPTY_ARTIFACTS: SessionState["artifacts"] = {
  policy_hits: [], kb_snippets: [], arch_options: [],
  selected_arch: null, roi_scorecard: {}, sprint_backlog: {}, final_plan: {},
};

const EMPTY_AGENTS: SessionState["agents"] = {
  supervisor:   { name: "supervisor",   status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
  policy:       { name: "policy",       status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
  kb:           { name: "kb",           status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
  architecture: { name: "architecture", status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
  web_research: { name: "web_research", status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
  business:     { name: "business",     status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
  sprint:       { name: "sprint",       status: "idle", task: "", output: "", confidence: "", artifacts: [], updated_at: "" },
};

export default function Home() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [agents, setAgents] = useState<SessionState["agents"]>(EMPTY_AGENTS);
  const [artifacts, setArtifacts] = useState<SessionState["artifacts"]>(EMPTY_ARTIFACTS);
  const [chunks, setChunks] = useState<TranscriptChunk[]>([]);
  const [summary, setSummary] = useState<MeetingSummary>(EMPTY_SUMMARY);
  const [checkpoints, setCheckpoints] = useState<CheckpointState[]>([]);
  const [finalPlan, setFinalPlan] = useState<FinalPlan | null>(null);
  const [showBoard, setShowBoard] = useState(false);

  const [isLoadingDemo, setIsLoadingDemo] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [audioActive, setAudioActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sseCleanupRef = useRef<(() => void) | null>(null);

  // ── SSE subscription ──
  const subscribeSSE = useCallback((id: string) => {
    if (sseCleanupRef.current) sseCleanupRef.current();

    const cleanup = createSSE(id, (event: SSEEvent) => {
      switch (event.type) {
        case "stage_change":
          setStage((event.data as { stage: Stage }).stage ?? "idle");
          break;
        case "agent_update": {
          const agent = event.data as SessionState["agents"][string];
          setAgents((prev) => ({ ...prev, [agent.name]: agent }));
          break;
        }
        case "transcript_chunk":
          setChunks((prev) => [...prev, event.data as TranscriptChunk]);
          break;
        case "meeting_summary":
          setSummary(event.data as MeetingSummary);
          break;
        case "artifact_update": {
          const { type: aType, data } = event.data as { type: string; data: unknown };
          setArtifacts((prev) => ({ ...prev, [aType]: data }));
          if (aType === "final_plan") {
            setFinalPlan(data as FinalPlan);
          }
          break;
        }
        case "checkpoint": {
          const cp = event.data as CheckpointState;
          setCheckpoints((prev) => prev.map((c) => (c.id === cp.id ? cp : c)));
          break;
        }
        case "done":
          setIsRunning(false);
          break;
        case "error":
          setError((event.data as { message: string }).message);
          setIsRunning(false);
          break;
      }
    });
    sseCleanupRef.current = cleanup;
  }, []);

  // ── Load demo ──
  const handleLoadDemo = async () => {
    setError(null);
    setIsLoadingDemo(true);
    try {
      const { session_id } = await api.loadDemo();
      setSessionId(session_id);

      // Fetch initial state to populate transcript
      const state = await api.getState(session_id);
      setChunks(state.transcript_count > 0
        ? Array.from({ length: state.transcript_count }, (_, i) => ({
          speaker: i % 2 === 0 ? "Riya" : "Arjun",
          text: "",
          timestamp: "",
        }))
        : []);

      // Refresh with actual chunks
      const fullState = await api.getState(session_id);
      setStage(fullState.stage);
      setAgents(fullState.agents);
      setArtifacts(fullState.artifacts);
      setCheckpoints(fullState.checkpoints);

      subscribeSSE(session_id);

      // Re-fetch transcript chunks by reloading demo (chunks are in transcript_chunks not exposed directly)
      // Re-load demo transcript into chunks manually
      const DEMO_CHUNKS: TranscriptChunk[] = [
        { speaker: "Riya", text: "We got the brief from Acme Capital. They want help with finance operations, especially employee expenses and vendor invoice exceptions.", timestamp: "" },
        { speaker: "Arjun", text: "Yes, and they were clear that they do not want final approval to be automated. The solution has to be decision support plus routing, not full autonomous approval.", timestamp: "" },
        { speaker: "Riya", text: "I think we should focus the MVP on expense review first because it is easier to explain in a demo.", timestamp: "" },
        { speaker: "Arjun", text: "We can ingest expense claims, read receipt images or PDFs, compare them against company policy, and classify the case as low, medium, or high risk.", timestamp: "" },
        { speaker: "Riya", text: "We should also make sure the model explains why it flagged something. The client called out reviewer mistrust if the AI cannot explain its reasoning.", timestamp: "" },
        { speaker: "Arjun", text: "The architecture is OCR plus document extraction, then a policy-grounded reasoning layer, then a reviewer dashboard with approve, reject, or escalate.", timestamp: "" },
        { speaker: "Riya", text: "Client data cannot be used to train public models, and any recommendation must stay explainable.", timestamp: "" },
        { speaker: "Arjun", text: "Azure-native is probably the safest path. Keep the knowledge base with policy docs and use retrieval during the reasoning step.", timestamp: "" },
        { speaker: "Riya", text: "If reviewers save even five minutes on a large chunk of low-risk cases, that could add up quickly. We should quantify that for the proposal.", timestamp: "" },
        { speaker: "Arjun", text: "Sprint 1 should validate ingestion plus policy-grounded review on one case type. Sprint 2 can improve the user workflow and escalation paths.", timestamp: "" },
        { speaker: "Riya", text: "Let us have Magic Meet convert this into a proposed architecture, value summary, and sprint backlog.", timestamp: "" },
      ];
      setChunks(DEMO_CHUNKS);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load demo");
    } finally {
      setIsLoadingDemo(false);
    }
  };

  // ── Start pipeline ──
  const handleStart = async () => {
    if (!sessionId) return;
    setError(null);
    setIsRunning(true);
    try {
      await api.startDemo();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to start pipeline");
      setIsRunning(false);
    }
  };

  // ── Checkpoint submit ──
  const handleCheckpoint = async (cpId: string, userInput: Record<string, unknown>) => {
    if (!sessionId) return;
    try {
      await api.submitCheckpoint(sessionId, cpId, userInput);
      setCheckpoints((prev) => prev.map((c) => c.id === cpId ? { ...c, status: "completed", user_input: userInput } : c));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Checkpoint failed");
    }
  };

  // ── Reset ──
  const handleReset = () => {
    sseCleanupRef.current?.();
    setSessionId(null);
    setStage("idle");
    setAgents(EMPTY_AGENTS);
    setArtifacts(EMPTY_ARTIFACTS);
    setChunks([]);
    setSummary(EMPTY_SUMMARY);
    setCheckpoints([]);
    setFinalPlan(null);
    setShowBoard(false);
    setIsRunning(false);
    setAudioActive(false);
    setError(null);
  };

  // ── Toggle live audio ──
  const handleAudioToggle = async () => {
    if (!sessionId) return;
    try {
      if (audioActive) {
        await api.audioStop();
        setAudioActive(false);
      } else {
        await api.audioStart(sessionId);
        setAudioActive(true);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Audio toggle failed");
    }
  };

  // Cleanup SSE on unmount
  useEffect(() => () => { sseCleanupRef.current?.(); }, []);

  // Active checkpoint
  const activeCheckpoint = checkpoints.find((c) => c.status === "active");

  const isDone = stage === "done";
  const canStart = !!sessionId && stage === "idle" && chunks.length > 0;
  const pipelineStarted = stage !== "idle";

  return (
    <div className="flex flex-col h-screen">
      {/* ── Top bar ── */}
      <header className="h-12 border-b border-gray-200 bg-white px-4 flex items-center justify-between shrink-0 shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-md bg-brand-600 flex items-center justify-center">
            <span className="text-white text-xs font-bold">M</span>
          </div>
          <span className="font-semibold text-gray-900">Magic Meet</span>
          <span className="text-gray-300">|</span>
          <span className="text-xs text-gray-500">Live AI Planning Workspace</span>
        </div>

        <div className="flex items-center gap-2">
          {error && (
            <span className="text-xs text-red-500 bg-red-50 px-2 py-1 rounded border border-red-200 max-w-xs truncate">
              {error}
            </span>
          )}

          {isDone && (
            <button
              onClick={() => setShowBoard(true)}
              className="btn-primary text-xs"
            >
              <LayoutDashboard size={13} />
              View Planning Board
            </button>
          )}

          {!sessionId ? (
            <button
              onClick={handleLoadDemo}
              disabled={isLoadingDemo}
              className="btn-primary text-xs"
            >
              {isLoadingDemo ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} />}
              Load Demo
            </button>
          ) : (
            <>
              {!pipelineStarted && (
                <button
                  onClick={handleStart}
                  disabled={!canStart || isRunning}
                  className="btn-primary text-xs"
                >
                  {isRunning ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} />}
                  Start Analysis
                </button>
              )}
              <button
                onClick={handleAudioToggle}
                className={clsx("btn text-xs border", audioActive
                  ? "bg-red-50 text-red-700 border-red-300 hover:bg-red-100"
                  : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
                )}
                title={audioActive ? "Stop audio capture" : "Start live audio capture"}
              >
                {audioActive ? <MicOff size={13} /> : <Mic size={13} />}
                {audioActive ? "Stop Audio" : "Live Audio"}
              </button>
              <button onClick={handleReset} className="btn-secondary text-xs">
                <RefreshCw size={13} />
                Reset
              </button>
            </>
          )}
        </div>
      </header>

      {/* ── Stage progress bar ── */}
      <StageBar stage={stage} />

      {/* ── Main 3-pane layout ── */}
      <main className="flex flex-1 min-h-0">
        {/* Left pane — Live Transcript */}
        <div className="w-72 xl:w-80 shrink-0 flex flex-col border-r border-gray-200 bg-white overflow-hidden">
          <LiveTranscript chunks={chunks} summary={summary} />
        </div>

        {/* Center pane — Agent Kitchen */}
        <div className="w-72 xl:w-80 shrink-0 flex flex-col border-r border-gray-200 bg-white overflow-hidden">
          <AgentKitchen agents={agents} stage={stage} />
        </div>

        {/* Right pane — Artifacts (fills remaining space) */}
        <div className="flex-1 flex flex-col bg-white overflow-hidden">
          <ArtifactsPane artifacts={artifacts} stage={stage} />
        </div>
      </main>

      {/* ── Checkpoint modal ── */}
      {activeCheckpoint && (
        <CheckpointModal
          checkpoint={activeCheckpoint}
          archOptions={artifacts.arch_options ?? []}
          onSubmit={handleCheckpoint}
        />
      )}

      {/* ── Final planning board overlay ── */}
      {showBoard && finalPlan && (
        <>
          <div className="fixed top-4 right-4 z-50">
            <button
              onClick={() => setShowBoard(false)}
              className="btn-secondary shadow-lg"
            >
              ← Back to workspace
            </button>
          </div>
          <PlanningBoard plan={finalPlan} />
        </>
      )}
    </div>
  );
}

// ── Stage progress ──
const STAGES: { key: Stage; label: string }[] = [
  { key: "preprocessing", label: "Preprocess" },
  { key: "stage1", label: "Policy & KB" },
  { key: "checkpoint1", label: "Checkpoint 1" },
  { key: "stage2", label: "Architecture" },
  { key: "checkpoint2", label: "Checkpoint 2" },
  { key: "stage3", label: "Biz & Sprint" },
  { key: "checkpoint3", label: "Checkpoint 3" },
  { key: "synthesis", label: "Synthesis" },
  { key: "done", label: "Done" },
];

const STAGE_ORDER: Stage[] = ["idle", "preprocessing", "stage0", "stage1", "checkpoint1", "stage2", "checkpoint2", "stage3", "checkpoint3", "synthesis", "done"];

function StageBar({ stage }: { stage: Stage }) {
  const currentIndex = STAGE_ORDER.indexOf(stage);

  return (
    <div className="h-8 bg-white border-b border-gray-100 px-4 flex items-center gap-1 overflow-x-auto shrink-0">
      {STAGES.map((s, i) => {
        const sIndex = STAGE_ORDER.indexOf(s.key);
        const done = currentIndex > sIndex;
        const active = stage === s.key || (s.key === "stage1" && stage === "stage0");
        const isCheckpoint = s.key.startsWith("checkpoint");

        return (
          <div key={s.key} className="flex items-center gap-1 shrink-0">
            {i > 0 && <div className="w-4 h-px bg-gray-200" />}
            <div
              className={clsx(
                "flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium transition-colors",
                {
                  "bg-brand-600 text-white": active,
                  "bg-green-100 text-green-700": done,
                  "bg-amber-100 text-amber-700": isCheckpoint && active,
                  "text-gray-400": !active && !done,
                }
              )}
            >
              {done && !active && <span>✓</span>}
              {s.label}
            </div>
          </div>
        );
      })}
    </div>
  );
}
