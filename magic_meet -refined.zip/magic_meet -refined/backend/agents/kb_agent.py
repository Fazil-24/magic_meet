"""
Knowledge Base Agent — retrieves relevant internal document snippets via Azure AI Search.
Falls back to loading the DOCX files directly when the index is not configured.
"""
import json
import os
from pathlib import Path
from utils.llm_client import chat
from services.session_state import SessionState

# Path to sample docs (relative to repo root)
DOCS_DIR = Path(__file__).parent.parent.parent / "docs"

SYSTEM_PROMPT = """You are a knowledge retrieval agent. Given a project question and document snippets,
extract the most relevant knowledge items that should inform the planning decision.

Return ONLY valid JSON:
{
  "snippets": [
    {"source": "document name", "relevance": "high|medium|low", "content": "relevant excerpt", "implication": "what this means for the project"}
  ],
  "key_findings": ["..."],
  "confidence": "high|medium|low"
}"""


def _load_docx_text(filename: str) -> str:
    """Load text from a DOCX file in the docs directory."""
    try:
        from docx import Document
        path = DOCS_DIR / filename
        if not path.exists():
            # Also try looking in the project root
            path = Path(__file__).parent.parent.parent / filename
        if not path.exists():
            return ""
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    except Exception:
        return ""


def _search_azure(query: str) -> list[dict]:
    """Query Azure AI Search. Returns list of result dicts."""
    try:
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential

        endpoint = os.environ.get("AZURE_SEARCH_ENDPOINT", "")
        api_key = os.environ.get("AZURE_SEARCH_API_KEY", "")
        index = os.environ.get("AZURE_SEARCH_INDEX", "magic-meet-kb")

        if not endpoint or not api_key or "YOUR_" in endpoint:
            return []

        client = SearchClient(endpoint, index, AzureKeyCredential(api_key))
        results = client.search(query, top=5, include_total_count=True)
        hits = []
        for r in results:
            content = r.get("content", r.get("chunk", r.get("text", "")))
            source = r.get("sourcefile", r.get("metadata_storage_name", "KB Document"))
            if content:
                hits.append({"source": source, "content": content[:600]})
        return hits
    except Exception:
        return []


def _load_local_docs() -> list[dict]:
    docs = [
        ("magic_meet_policy_guardrails.docx", "Neural Systems Policy & Guardrails"),
        ("magic_meet_client_requirements.docx", "Acme Capital Client Brief"),
        ("magic_meet_business_metrics.docx", "Business & Cost Metrics"),
    ]
    results = []
    for filename, label in docs:
        text = _load_docx_text(filename)
        if text:
            results.append({"source": label, "content": text[:800]})
    return results


def run(session: SessionState) -> dict:
    session.update_agent(
        "kb",
        status="running",
        task="Retrieving relevant internal knowledge",
        confidence="",
    )

    summary = session.meeting_summary
    query = " ".join(summary.get("goals", []) + summary.get("proposed_solutions", []))
    if not query:
        query = "finance AI expense review policy compliance"

    # Try Azure AI Search first, fall back to local DOCX
    azure_hits = _search_azure(query)
    doc_snippets = azure_hits if azure_hits else _load_local_docs()

    if not doc_snippets:
        session.update_agent("kb", status="error", task="No documents found", confidence="low")
        return {}

    snippets_text = json.dumps(doc_snippets, indent=2)
    user_content = (
        f"Project goals:\n{json.dumps(summary.get('goals', []), indent=2)}\n\n"
        f"Proposed solutions:\n{json.dumps(summary.get('proposed_solutions', []), indent=2)}\n\n"
        f"Document snippets:\n{snippets_text}"
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_content},
    ]

    try:
        raw = chat(messages, temperature=0.1, max_tokens=1500)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception:
        result = {
            "snippets": [{"source": s["source"], "relevance": "high", "content": s["content"][:200], "implication": "See source document"} for s in doc_snippets[:3]],
            "key_findings": ["Policy grounding required for finance AI", "Human review must be preserved"],
            "confidence": "medium",
        }

    session.artifacts["kb_snippets"] = result.get("snippets", [])
    session.push_event("artifact_update", {"type": "kb_snippets", "data": result.get("snippets", [])})

    session.update_agent(
        "kb",
        status="done",
        task="Knowledge retrieval complete",
        output=f"Retrieved {len(result.get('snippets', []))} relevant snippets. "
               f"Key: {'; '.join(result.get('key_findings', [])[:2])}",
        confidence=result.get("confidence", "medium"),
        artifacts=result.get("snippets", []),
    )
    return result
