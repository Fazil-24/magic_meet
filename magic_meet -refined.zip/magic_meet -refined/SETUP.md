# Magic Meet — Setup Guide

## Prerequisites

- Python 3.11+
- Node.js 18+
- Windows 10/11 (for audio capture)
- VB-CABLE (for Zoom audio capture — optional, needed only for live calls)

---

## 1. Install VB-CABLE (Windows audio routing)

1. Download from https://vb-audio.com/Cable/
2. Run installer as Administrator, reboot
3. In Zoom Settings → Audio → Speaker: set to **CABLE Input (VB-Audio Virtual Cable)**
4. Your physical speakers will still hear audio via your normal output

---

## 2. Download Faster-Whisper medium model

The model downloads automatically on first use (~1.5 GB).
To pre-download it manually:

```powershell
pip install faster-whisper
python -c "from faster_whisper import WhisperModel; WhisperModel('medium', device='cpu', compute_type='int8')"
```

---

## 3. Backend setup

```powershell
cd backend

# Create virtual environment
python -m venv venv
.\venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Configure environment
Copy-Item .env.example .env
# Edit .env and fill in your Azure keys
notepad .env
```

### .env values to fill in

| Key | Where to find it |
|-----|-----------------|
| `AZURE_OPENAI_ENDPOINT` | Azure Portal → your OpenAI resource → Keys and Endpoint |
| `AZURE_OPENAI_API_KEY` | Same page, Key 1 or Key 2 |
| `AZURE_OPENAI_DEPLOYMENT` | Azure AI Foundry → Deployments → your GPT-4.1 deployment name |
| `AZURE_SEARCH_ENDPOINT` | Azure Portal → your AI Search resource → Overview |
| `AZURE_SEARCH_API_KEY` | AI Search → Keys → Admin key |
| `AZURE_SEARCH_INDEX` | The index name where you uploaded the 4 DOCX files |

> **Note:** If Azure Search is not configured, the system will automatically fall back to reading the local DOCX files in `/docs/`.

### Start the backend

```powershell
python app.py
# Runs on http://localhost:5000
```

---

## 4. Frontend setup

```powershell
cd frontend
npm install
npm run dev
# Runs on http://localhost:3000
```

---

## 5. Upload documents to Azure AI Search (optional but recommended)

1. Go to Azure AI Search → Import data
2. Data source: Azure Blob Storage (upload the 4 DOCX files) or use the built-in import wizard
3. Set the index name to match `AZURE_SEARCH_INDEX` in your `.env`
4. Enable semantic search if available

---

## 6. Running the demo

1. Open http://localhost:3000
2. Click **Load Demo** — loads the sample Acme Capital transcript
3. Click **Start Analysis** — pipeline begins running
4. Watch agents work in the center pane
5. Respond to the 3 human checkpoints when they appear
6. Click **View Planning Board** when done

---

## 7. Live Zoom call mode

1. Start a backend session via the UI (or POST /api/session/create)
2. Join your Zoom call (speaker set to CABLE Input)
3. Click **Live Audio** in the top bar
4. Speak — your mic and the meeting audio will be transcribed live
5. When enough transcript has accumulated, click **Start Analysis**

---

## Project structure

```
magic_meet/
├── backend/
│   ├── app.py                  Flask API
│   ├── requirements.txt
│   ├── .env.example
│   ├── agents/
│   │   ├── orchestrator.py     Pipeline runner
│   │   ├── supervisor.py
│   │   ├── policy_agent.py
│   │   ├── kb_agent.py
│   │   ├── web_research_agent.py
│   │   ├── architecture_agent.py
│   │   ├── business_agent.py
│   │   └── sprint_agent.py
│   ├── services/
│   │   ├── session_state.py    In-memory state + SSE queue
│   │   ├── preprocessor.py     Transcript → structured summary
│   │   └── audio_capture.py    VB-CABLE + mic → Whisper
│   └── utils/
│       └── llm_client.py       Azure OpenAI wrapper
├── frontend/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx            Main 3-pane workspace
│   │   └── globals.css
│   ├── components/
│   │   ├── LiveTranscript.tsx
│   │   ├── AgentKitchen.tsx
│   │   ├── ArtifactsPane.tsx
│   │   ├── CheckpointModal.tsx
│   │   └── PlanningBoard.tsx
│   └── lib/
│       ├── api.ts              Backend API client + SSE helper
│       └── types.ts            Shared TypeScript types
└── docs/                       Sample DOCX knowledge base files
```
