"use client";
import { useState } from "react";
import { CheckpointState, ArchOption } from "@/lib/types";
import { AlertCircle, CheckCircle2, ChevronRight } from "lucide-react";

interface Props {
  checkpoint: CheckpointState;
  archOptions?: ArchOption[];
  onSubmit: (cpId: string, userInput: Record<string, unknown>) => void;
}

export default function CheckpointModal({ checkpoint, archOptions = [], onSubmit }: Props) {
  const [extraConstraint, setExtraConstraint] = useState("");
  const [priorityWorkflow, setPriorityWorkflow] = useState("expense_review");
  const [selectedArch, setSelectedArch] = useState(archOptions.find((o) => o.recommended)?.id ?? "");
  const [engineers, setEngineers] = useState(2);
  const [dataEngineers, setDataEngineers] = useState(1);
  const [sprintWeeks, setSprintWeeks] = useState(2);
  const [dailyCases, setDailyCases] = useState(50);

  const handleSubmit = () => {
    if (checkpoint.id === "cp1") {
      onSubmit(checkpoint.id, {
        priority_workflow: priorityWorkflow,
        extra_constraints: extraConstraint ? [extraConstraint] : [],
      });
    } else if (checkpoint.id === "cp2") {
      onSubmit(checkpoint.id, { selected_option: selectedArch });
    } else if (checkpoint.id === "cp3") {
      onSubmit(checkpoint.id, {
        engineers,
        data_engineers: dataEngineers,
        sprint_length_weeks: sprintWeeks,
        daily_cases: dailyCases,
        pm: 1,
        timeline_weeks: sprintWeeks * 5,
      });
    }
  };

  if (checkpoint.status !== "active") return null;

  return (
    <div className="fixed inset-0 bg-black/30 flex items-end sm:items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center shrink-0">
            <AlertCircle size={16} className="text-brand-600" />
          </div>
          <div>
            <h2 className="font-semibold text-gray-900">{checkpoint.title}</h2>
            <p className="text-xs text-gray-500 mt-0.5">{checkpoint.description}</p>
          </div>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-4">
          {checkpoint.id === "cp1" && (
            <>
              <Field label="Priority Workflow">
                <div className="flex gap-2">
                  {["expense_review", "invoice_exceptions"].map((opt) => (
                    <button
                      key={opt}
                      onClick={() => setPriorityWorkflow(opt)}
                      className={`flex-1 py-2 px-3 rounded-md border text-xs font-medium transition-colors ${
                        priorityWorkflow === opt
                          ? "bg-brand-600 text-white border-brand-600"
                          : "bg-white text-gray-700 border-gray-300 hover:border-brand-400"
                      }`}
                    >
                      {opt === "expense_review" ? "Employee Expense Review" : "Invoice Exceptions"}
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="Additional Constraint (optional)">
                <input
                  type="text"
                  value={extraConstraint}
                  onChange={(e) => setExtraConstraint(e.target.value)}
                  placeholder="e.g. Must support single sign-on"
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                />
              </Field>
            </>
          )}

          {checkpoint.id === "cp2" && archOptions.length > 0 && (
            <Field label="Select Architecture Option">
              <div className="space-y-2">
                {archOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedArch(opt.id)}
                    className={`w-full text-left p-3 rounded-md border transition-colors ${
                      selectedArch === opt.id
                        ? "border-brand-500 bg-brand-50"
                        : "border-gray-200 hover:border-brand-300"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-sm text-gray-800">{opt.title}</span>
                      <div className="flex gap-1">
                        {opt.recommended && <span className="badge badge-blue">Recommended</span>}
                        <span className={`badge ${opt.effort === "low" ? "badge-green" : opt.effort === "medium" ? "badge-yellow" : "badge-red"}`}>
                          {opt.effort} effort
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">{opt.summary}</p>
                  </button>
                ))}
              </div>
            </Field>
          )}

          {checkpoint.id === "cp3" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Engineers">
                  <NumberInput value={engineers} onChange={setEngineers} min={1} max={10} />
                </Field>
                <Field label="Data Engineers">
                  <NumberInput value={dataEngineers} onChange={setDataEngineers} min={0} max={5} />
                </Field>
                <Field label="Sprint Length (weeks)">
                  <NumberInput value={sprintWeeks} onChange={setSprintWeeks} min={1} max={4} />
                </Field>
                <Field label="Daily Cases (est.)">
                  <NumberInput value={dailyCases} onChange={setDailyCases} min={10} max={500} step={10} />
                </Field>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-2">
          <button
            onClick={handleSubmit}
            className="btn-primary"
          >
            <CheckCircle2 size={15} />
            Continue
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-700 mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function NumberInput({
  value, onChange, min, max, step = 1,
}: {
  value: number; onChange: (v: number) => void; min: number; max: number; step?: number;
}) {
  return (
    <input
      type="number"
      value={value}
      min={min}
      max={max}
      step={step}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
    />
  );
}
