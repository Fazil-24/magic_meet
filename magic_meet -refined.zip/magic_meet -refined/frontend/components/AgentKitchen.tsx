"use client";
import { AgentState, Stage } from "@/lib/types";
import { StatusDot } from "./StatusDot";
import { ConfidenceBadge } from "./ConfidenceBadge";
import { ChefHat, ShieldCheck, Database, Code2, Globe, TrendingUp, CalendarDays, Bot } from "lucide-react";

interface Props {
  agents: Record<string, AgentState>;
  stage: Stage;
}

const AGENT_META: Record<string, { label: string; icon: React.ReactNode; stageHint: string }> = {
  supervisor:    { label: "Supervisor",    icon: <Bot size={14} />,          stageHint: "Orchestrates all agents" },
  policy:        { label: "Policy",        icon: <ShieldCheck size={14} />,  stageHint: "Stage 1 — Guardrail check" },
  kb:            { label: "Knowledge Base",icon: <Database size={14} />,     stageHint: "Stage 1 — Internal docs" },
  architecture:  { label: "Architecture",  icon: <Code2 size={14} />,        stageHint: "Stage 2 — Design patterns" },
  web_research:  { label: "Web Research",  icon: <Globe size={14} />,        stageHint: "Stage 2 — External research" },
  business:      { label: "Business / ROI",icon: <TrendingUp size={14} />,   stageHint: "Stage 3 — Value estimate" },
  sprint:        { label: "Sprint Planner",icon: <CalendarDays size={14} />, stageHint: "Stage 3 — Backlog" },
};

const AGENT_ORDER = ["supervisor", "policy", "kb", "architecture", "web_research", "business", "sprint"];

const STAGE_LABELS: Record<Stage, string> = {
  idle:          "Waiting to start",
  preprocessing: "Preprocessing transcript…",
  stage0:        "Supervisor classifying stage…",
  stage1:        "Stage 1 — Policy & Knowledge",
  checkpoint1:   "⏸ Checkpoint 1 — Refine Constraints",
  stage2:        "Stage 2 — Architecture & Research",
  checkpoint2:   "⏸ Checkpoint 2 — Select Architecture",
  stage3:        "Stage 3 — Business & Sprint",
  checkpoint3:   "⏸ Checkpoint 3 — Confirm Sprint Plan",
  synthesis:     "Synthesising final plan…",
  done:          "Planning board ready",
};

export default function AgentKitchen({ agents, stage }: Props) {
  return (
    <div className="pane border-r">
      <div className="pane-header">
        <div className="flex items-center gap-2">
          <ChefHat size={15} className="text-brand-600" />
          <span className="font-semibold text-gray-800">Agent Kitchen</span>
        </div>
        <span className="badge badge-blue text-xs">{STAGE_LABELS[stage] ?? stage}</span>
      </div>

      <div className="pane-body">
        {AGENT_ORDER.map((key) => {
          const agent = agents[key];
          const meta = AGENT_META[key];
          if (!agent || !meta) return null;
          return (
            <AgentCard key={key} agent={agent} meta={meta} />
          );
        })}
      </div>
    </div>
  );
}

function AgentCard({
  agent,
  meta,
}: {
  agent: AgentState;
  meta: { label: string; icon: React.ReactNode; stageHint: string };
}) {
  const isActive = agent.status === "running";

  return (
    <div className={`card transition-shadow ${isActive ? "shadow-md ring-1 ring-blue-200" : ""}`}>
      <div className="card-header">
        <div className="flex items-center gap-2 min-w-0">
          <StatusDot status={agent.status} />
          <span className="text-gray-600">{meta.icon}</span>
          <span className="font-medium text-gray-800 truncate">{meta.label}</span>
        </div>
        <ConfidenceBadge confidence={agent.confidence} />
      </div>

      <div className="card-body space-y-1.5">
        <p className="text-xs text-gray-500">
          {agent.task || meta.stageHint}
        </p>
        {agent.output && (
          <p className="text-xs text-gray-700 bg-gray-50 rounded p-2 border border-gray-100 leading-relaxed">
            {agent.output}
          </p>
        )}
        {isActive && (
          <div className="flex gap-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 150}ms` }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
