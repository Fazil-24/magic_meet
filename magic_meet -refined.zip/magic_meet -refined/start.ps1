# Magic Meet — Start both backend and frontend
# Run from the magic_meet root: .\start.ps1

$ErrorActionPreference = "Stop"

Write-Host "Starting Magic Meet..." -ForegroundColor Cyan

# Backend
Start-Process powershell -ArgumentList "-NoExit", "-Command", @"
  cd '$PSScriptRoot\backend'
  if (Test-Path 'venv\Scripts\Activate.ps1') {
    .\venv\Scripts\Activate.ps1
  }
  python app.py
"@

Start-Sleep -Seconds 2

# Frontend
Start-Process powershell -ArgumentList "-NoExit", "-Command", @"
  cd '$PSScriptRoot\frontend'
  npm run dev
"@

Write-Host ""
Write-Host "Backend:  http://localhost:5000" -ForegroundColor Green
Write-Host "Frontend: http://localhost:3000" -ForegroundColor Green
Write-Host ""
Write-Host "Opening browser..." -ForegroundColor Yellow
Start-Sleep -Seconds 4
Start-Process "http://localhost:3000"
