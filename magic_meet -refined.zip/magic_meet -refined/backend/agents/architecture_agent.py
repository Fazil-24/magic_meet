"""
Architecture / SME Agent — proposes 2-3 architecture patterns with tradeoffs.
Combines internal KB, policy context, and web research findings.
"""
import json
from utils.llm_client import chat
from services.session_state import SessionState

SYSTEM_PROMPT = """You are a senior solutions architect. Based on the project context, propose exactly 3
architecture options. Each option must be realistic, Azure-native preferred, and grounded in the constraints.

Return ONLY valid JSON:
{
  "options": [
    {
      "id": "option_a",
      "title": "Short title",
      "summary": "2-sentence description",
      "components": ["component1", "component2"],
      "pros": ["pro1", "pro2"],
      "cons": ["con1"],
      "effort": "low|medium|high",
      "compliance_confidence": "high|medium|low",
      "recommended": false
    }
  ],
  "recommendation": "option_a|option_b|option_c",
  "recommendation_rationale": "why this option is best given the constraints",
  "confidence": "high|medium|low"
}
Mark exactly one option as recommended: true."""


def run(session: SessionState) -> dict:
    session.update_agent(
        "architecture",
        status="running",
        task="Synthesising architecture options from internal context and research",
        confidence="",
    )

    summary = session.meeting_summary
    policy_hits = session.artifacts.get("policy_hits", [])
    kb_snippets = session.artifacts.get("kb_snippets", [])
    web_findings = session.artifacts.get("web_findings", [])
    cp1_input = {}
    for cp in session.checkpoints:
        if cp.id == "cp1":
            cp1_input = cp.user_input

    context = {
        "goals": summary.get("goals", []),
        "constraints": summary.get("constraints", []) + list(cp1_input.get("extra_constraints", [])),
        "proposed_solutions": summary.get("proposed_solutions", []),
        "policy_concerns": [h.get("rule", "") for h in policy_hits if h.get("status") != "pass"],
        "kb_key_findings": [s.get("implication", "") for s in kb_snippets[:4]],
        "web_patterns": [f.get("insight", "") for f in web_findings[:4]],
        "selected_focus": cp1_input.get("priority_workflow", "expense_review"),
    }

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Project context:\n{json.dumps(context, indent=2)}"},
    ]

    try:
        raw = chat(messages, temperature=0.4, max_tokens=2000)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception:
        result = _fallback_options()

    session.artifacts["arch_options"] = result.get("options", [])
    session.push_event("artifact_update", {"type": "arch_options", "data": result.get("options", [])})

    rec = result.get("recommendation", "")
    session.update_agent(
        "architecture",
        status="done",
        task="Architecture options ready",
        output=f"3 options generated. Recommended: {rec}. {result.get('recommendation_rationale', '')[:100]}",
        confidence=result.get("confidence", "high"),
        artifacts=result.get("options", []),
    )
    return result


def _fallback_options() -> dict:
    return {
        "options": [
            {
                "id": "option_a",
                "title": "Azure Doc Intelligence + GPT-4 + Approval Portal",
                "summary": "Ingest receipts via Azure Document Intelligence, reason with GPT-4 against policy KB, route to a reviewer portal with approve/reject/escalate.",
                "components": ["Azure Document Intelligence", "Azure OpenAI GPT-4", "Azure AI Search (Policy KB)", "React Reviewer Portal", "Azure Functions"],
                "pros": ["Fully Azure-native", "Strong explainability", "Human approval built-in"],
                "cons": ["Moderate setup effort for Document Intelligence"],
                "effort": "medium",
                "compliance_confidence": "high",
                "recommended": True,
            },
            {
                "id": "option_b",
                "title": "Direct LLM Classification + Rules Engine",
                "summary": "Parse documents with PDF extraction, classify with GPT-4 + a deterministic rules layer, email notifications for reviewer actions.",
                "components": ["PyMuPDF / pdfplumber", "Azure OpenAI GPT-4", "Python Rules Engine", "Email Workflow"],
                "pros": ["Faster to build", "Lower cost"],
                "cons": ["Less accurate OCR", "Limited audit trail"],
                "effort": "low",
                "compliance_confidence": "medium",
                "recommended": False,
            },
            {
                "id": "option_c",
                "title": "Full Azure AI Foundry RAG Pipeline",
                "summary": "End-to-end Azure AI Foundry pipeline: document ingestion, vector indexing, retrieval-augmented generation, integrated reviewer UX.",
                "components": ["Azure AI Foundry", "Azure Blob Storage", "Azure AI Search Vector", "Azure OpenAI", "Power Apps Reviewer UI"],
                "pros": ["Enterprise-grade", "Scalable", "Low-code reviewer UI"],
                "cons": ["Higher infra cost", "Longer setup time"],
                "effort": "high",
                "compliance_confidence": "high",
                "recommended": False,
            },
        ],
        "recommendation": "option_a",
        "recommendation_rationale": "Best balance of explainability, compliance confidence, and time-to-pilot given the 8-12 week constraint.",
        "confidence": "high",
    }
