const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000";

async function req<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`API ${path} failed (${res.status}): ${text}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  loadDemo: () => req<{ session_id: string; chunks: number }>("/api/demo/load", { method: "POST" }),
  startDemo: () => req<{ ok: boolean }>("/api/demo/start", { method: "POST" }),
  getState: (id: string) => req<import("./types").SessionState>(`/api/session/${id}/state`),
  getArtifacts: (id: string) => req<import("./types").SessionState["artifacts"]>(`/api/session/${id}/artifacts`),
  submitCheckpoint: (id: string, checkpointId: string, userInput: Record<string, unknown>) =>
    req<{ ok: boolean }>(`/api/session/${id}/checkpoint`, {
      method: "POST",
      body: JSON.stringify({ checkpoint_id: checkpointId, user_input: userInput }),
    }),
  ingestTranscript: (id: string, speaker: string, text: string) =>
    req<{ ok: boolean }>(`/api/session/${id}/transcript`, {
      method: "POST",
      body: JSON.stringify({ speaker, text }),
    }),
  startPipeline: (id: string) =>
    req<{ ok: boolean }>(`/api/session/${id}/start`, { method: "POST" }),
  audioDevices: () => req<Array<{ index: number; name: string; channels: number }>>("/api/audio/devices"),
  audioStart: (sessionId: string) =>
    req<{ ok: boolean }>("/api/audio/start", { method: "POST", body: JSON.stringify({ session_id: sessionId }) }),
  audioStop: () => req<{ ok: boolean }>("/api/audio/stop", { method: "POST" }),
};

export function createSSE(sessionId: string, onEvent: (e: import("./types").SSEEvent) => void): () => void {
  const url = `${BASE}/api/session/${sessionId}/stream`;
  const es = new EventSource(url);

  es.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data) as import("./types").SSEEvent;
      onEvent(data);
    } catch {
      // ignore malformed events
    }
  };

  es.onerror = () => {
    es.close();
  };

  return () => es.close();
}
