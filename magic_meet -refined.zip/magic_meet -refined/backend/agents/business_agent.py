"""
Business / ROI Agent — estimates value, cost, and time-to-value using the business metrics doc.
"""
import json
from utils.llm_client import chat
from services.session_state import SessionState

# Embedded from magic_meet_business_metrics.docx
METRICS_CONTEXT = """
NEURAL SYSTEMS BUSINESS METRICS (defaults):
- ROI = (Annual Time Saved Value + Avoided Error Cost + Capacity Gain - Annual Operating Cost) / Implementation Cost
- Manual reviewer time saved per low-complexity case: 4-7 minutes
- Manual reviewer time saved per medium-complexity case: 8-15 minutes
- 1 engineering sprint = 2 weeks; 8 effective delivery days per sprint
- Engineer: $500/day, Data Engineer: $600/day, PM: $550/day, SME: $700/day
- Strong ROI: payback < 6 months; Moderate: 6-12 months; Weak: > 12 months
- Sprint 1: validate ingestion + policy grounding + one decision-support workflow
- Sprint 2: reviewer UX, explanations, escalation paths
- Score solutions 1-5 on: Business Value, Implementation Effort, Time to Pilot,
  Compliance Confidence, User Trust/Explainability, Long-term Extensibility
"""

SYSTEM_PROMPT = """You are a business value and ROI analyst at Neural Systems.
Estimate the business value and ROI for the selected solution using the metrics framework provided.

Return ONLY valid JSON:
{
  "assumptions": ["assumption 1", "assumption 2"],
  "time_savings": {
    "low_risk_cases_per_day": 0,
    "medium_risk_cases_per_day": 0,
    "minutes_saved_per_low": 0,
    "minutes_saved_per_medium": 0,
    "total_hours_saved_per_year": 0
  },
  "cost_estimate": {
    "implementation_days": 0,
    "implementation_cost_usd": 0,
    "annual_operating_cost_usd": 0
  },
  "roi": {
    "annual_value_usd": 0,
    "payback_months": 0,
    "band": "strong|moderate|weak"
  },
  "scoring": {
    "business_value": 0,
    "implementation_effort": 0,
    "time_to_pilot": 0,
    "compliance_confidence": 0,
    "user_trust": 0,
    "extensibility": 0
  },
  "summary": "2-sentence plain English ROI summary",
  "confidence": "high|medium|low"
}
All numeric values must be integers or floats. No null values."""


def run(session: SessionState) -> dict:
    session.update_agent(
        "business",
        status="running",
        task="Estimating ROI and business value",
        confidence="",
    )

    summary = session.meeting_summary
    selected_arch = session.artifacts.get("selected_arch") or {}
    cp2_input = {}
    for cp in session.checkpoints:
        if cp.id == "cp2":
            cp2_input = cp.user_input

    context = {
        "goals": summary.get("goals", []),
        "selected_architecture": selected_arch.get("title", "Azure Doc Intelligence + GPT-4 + Approval Portal"),
        "team_size": cp2_input.get("team_size", "1 PM, 2 engineers, 1 data engineer, 1 SME"),
        "timeline_weeks": cp2_input.get("timeline_weeks", 10),
        "primary_workflow": "employee expense review",
        "estimated_daily_cases": cp2_input.get("daily_cases", 50),
    }

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Metrics framework:\n{METRICS_CONTEXT}\n\nProject context:\n{json.dumps(context, indent=2)}"},
    ]

    try:
        raw = chat(messages, temperature=0.2, max_tokens=1200)
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        result = json.loads(raw)
    except Exception:
        result = _fallback_roi()

    session.artifacts["roi_scorecard"] = result
    session.push_event("artifact_update", {"type": "roi_scorecard", "data": result})

    roi = result.get("roi", {})
    session.update_agent(
        "business",
        status="done",
        task="ROI analysis complete",
        output=f"Payback: {roi.get('payback_months', '?')} months ({roi.get('band', 'unknown').upper()}). "
               f"Annual value: ${roi.get('annual_value_usd', 0):,}",
        confidence=result.get("confidence", "medium"),
        artifacts=[result],
    )
    return result


def _fallback_roi() -> dict:
    return {
        "assumptions": [
            "50 expense claims processed per day",
            "60% classified as low-risk (30 cases × 5.5 min saved)",
            "25% medium-risk (12 cases × 11 min saved)",
            "250 working days per year",
            "Reviewer fully loaded cost $80/hour",
        ],
        "time_savings": {
            "low_risk_cases_per_day": 30,
            "medium_risk_cases_per_day": 12,
            "minutes_saved_per_low": 5,
            "minutes_saved_per_medium": 11,
            "total_hours_saved_per_year": 1087,
        },
        "cost_estimate": {
            "implementation_days": 55,
            "implementation_cost_usd": 31500,
            "annual_operating_cost_usd": 8000,
        },
        "roi": {
            "annual_value_usd": 87000,
            "payback_months": 5,
            "band": "strong",
        },
        "scoring": {
            "business_value": 4,
            "implementation_effort": 3,
            "time_to_pilot": 4,
            "compliance_confidence": 5,
            "user_trust": 4,
            "extensibility": 4,
        },
        "summary": "Strong ROI case with projected payback in ~5 months. Primary value driver is reviewer time saved on low-to-medium risk cases.",
        "confidence": "medium",
    }
