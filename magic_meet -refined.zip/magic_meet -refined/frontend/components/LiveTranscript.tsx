"use client";
import { useEffect, useRef } from "react";
import { MeetingSummary, TranscriptChunk } from "@/lib/types";
import { Mic, Target, AlertTriangle, HelpCircle } from "lucide-react";

interface Props {
  chunks: TranscriptChunk[];
  summary: MeetingSummary;
}

const SPEAKER_COLORS: Record<string, string> = {
  Riya:    "bg-purple-100 text-purple-800",
  Arjun:   "bg-blue-100 text-blue-800",
  You:     "bg-green-100 text-green-800",
  Meeting: "bg-gray-100 text-gray-700",
};

function speakerColor(name: string): string {
  return SPEAKER_COLORS[name] ?? "bg-gray-100 text-gray-700";
}

export default function LiveTranscript({ chunks, summary }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chunks.length]);

  return (
    <div className="pane border-r">
      <div className="pane-header">
        <div className="flex items-center gap-2">
          <Mic size={15} className="text-brand-600" />
          <span className="font-semibold text-gray-800">Live Meeting</span>
        </div>
        <span className="badge badge-blue">{chunks.length} lines</span>
      </div>

      {/* Transcript scroll */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 min-h-0">
        {chunks.length === 0 && (
          <p className="text-gray-400 text-xs text-center mt-8">
            Transcript will appear here as the meeting progresses.
          </p>
        )}
        {chunks.map((c, i) => (
          <div key={i} className="flex gap-2 items-start">
            <span className={`badge shrink-0 ${speakerColor(c.speaker)}`}>{c.speaker}</span>
            <p className="text-gray-700 leading-relaxed text-xs">{c.text}</p>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Extracted insights */}
      {(summary.goals?.length > 0 || summary.constraints?.length > 0) && (
        <div className="border-t border-gray-100 p-3 space-y-3 shrink-0 bg-gray-50">
          {summary.goals?.length > 0 && (
            <div>
              <div className="flex items-center gap-1.5 mb-1.5">
                <Target size={12} className="text-brand-600" />
                <span className="section-title">Goals Detected</span>
              </div>
              <ul className="space-y-1">
                {summary.goals.map((g, i) => (
                  <li key={i} className="text-xs text-gray-700 flex gap-1.5">
                    <span className="text-brand-400 shrink-0">•</span>
                    {g}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {summary.constraints?.length > 0 && (
            <div>
              <div className="flex items-center gap-1.5 mb-1.5">
                <AlertTriangle size={12} className="text-amber-500" />
                <span className="section-title">Constraints</span>
              </div>
              <ul className="space-y-1">
                {summary.constraints.map((c, i) => (
                  <li key={i} className="text-xs text-gray-700 flex gap-1.5">
                    <span className="text-amber-400 shrink-0">•</span>
                    {c}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {summary.open_questions?.length > 0 && (
            <div>
              <div className="flex items-center gap-1.5 mb-1.5">
                <HelpCircle size={12} className="text-gray-500" />
                <span className="section-title">Open Questions</span>
              </div>
              <ul className="space-y-1">
                {summary.open_questions.map((q, i) => (
                  <li key={i} className="text-xs text-gray-600 flex gap-1.5">
                    <span className="text-gray-400 shrink-0">?</span>
                    {q}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
